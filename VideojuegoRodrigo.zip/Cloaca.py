# encoding: UTF-8
# Autor: Rodrigo García López
# Descripción: Proyecto Final Videojuego / Este programa corresponde al juego en ejecución

from Graphics import *
from random import randint, shuffle
from time import sleep
from Myro import makeSound, ask
# Ventanas
ventanaJ = Window("Jugando", 996, 699) #Ventana de juego
ventanaMenu = Window("Menu Principal", 1072, 600) #Ventana del menú
ventanaMP = Window("Mayores Puntajes", 1071, 600) #Ventana mayores puntajes
ventanaI = Window("Instrucciones", 1197, 600) # Ventana de instrucciones-
# Estado de las ventanas
ventanaJ.Visible = False
ventanaMP.Visible = False
ventanaI.Visible = False
# Botones para comprar torres y llamar oleada
botonIniciar = Button((908, 242), "Iniciar")
botonT1 = Button((397, 182), "Comprar: $50")
botonT2 = Button((545, 182), "Comprar: $150")
botonT3 = Button((693, 182), "Comprar: $250")
botonT4 = Button((847, 182), "Comprar: $60")
# Botones del menú principal
botonPlay = Button((600, 300), "Play")
botonMP = Button((565, 350), "Mayores Puntajes")
botonI = Button((580, 400), "Instrucciones")
botonSalir = Button((595, 450), "Salir")
botonRegresar = Button((1000, 560), "Regresar")
botonRegresar2 = Button((1110, 560), "Regresar")
# Indicadores principales del juego
vidas = 10
dinero = 140
oleada = 0
# Cuadros de textos que muestran los indicadores principales del juego
txtOleada = Text((150, 45), str(oleada))
txtDinero = Text((150, 100), str(dinero))
txtVidas = Text((150, 150), str(vidas))
# Cuadro de texto para mostrar cualquier mensaje importante al usuario
txtMensaje = Text((750, 280), "")
# Cuadro de texto con los usuarios con mayores puntajes
txtPuntajes = Text((800, 396), "")
txtUsuarios = Text((600, 400), "")
# Sonidos
ambiente = makeSound("Musica/MonsterCave.wav")
gritoMonstruo = makeSound("Musica/MonsterScream.wav")
chillidoRatas = makeSound("Musica/RatSqueak.wav")
roar = makeSound("Musica/Roar.wav")
cannon1 = makeSound("Musica/Cannon1.wav")
cannon2 = makeSound("Musica/Cannon2.wav")
cannon3 = makeSound("Musica/Cannon3.wav")
bombas = makeSound("Musica/Bombas.wav")
# Variable que se activa cuando se da click en boton salir
salir = False
# Función para crear enemigos, los parametros corresponden al número de enemigos de cada tipo que se desea crear
def crearEnemigos(nRata1, nRata2, nRata3, nCaiman, nSerpiente, nMonstruo):
    listaEnemigos = []
    for i in range (0, nRata1):
        R1 = makePicture("Imagenes/Enemigos/R1.png")
        listaEnemigos.append([R1,50,10,2]) #Objeto, vida, velocidad y dinero que se otorga al matarlo
    for i in range (0, nRata2):
        R2 = makePicture("Imagenes/Enemigos/R2.png")
        listaEnemigos.append([R2,350,4,15])
    for i in range (0, nRata3):
        R3 = makePicture("Imagenes/Enemigos/R3.png")
        listaEnemigos.append([R3,675,6,15])
    for i in range (0, nCaiman):
        A1 = makePicture("Imagenes/Enemigos/A1.png")
        listaEnemigos.append([A1,1250,4,15])
    for i in range (0, nSerpiente):
        S1 = makePicture("Imagenes/Enemigos/S1.png")
        listaEnemigos.append([S1,2500,6,20])
    for i in range (0, nMonstruo):
        M1 = makePicture("Imagenes/Enemigos/M1.png")
        listaEnemigos.append([M1,5750,2,30])
    shuffle(listaEnemigos)
    return listaEnemigos
# Listas de proyectiles
proyectiles = []
# Funciones para crear proyectiles
def crearProyectil(xi, yi, dxi, dy, ve, torre): # xi = posición inicial del proyectil en x; yi = posición inicial del proyectil en y; dxi = diferencia de posiciones iniciales entre la torre y el enemigo al que dispara en x; dyi = diferencia de posiciones iniciales entre la torre y el enmigo al que dispara en y; ve = velocidad del enemigo al que se está disparando
    if torre == 1:
        vp = 20
        dano = 50 #daño
        proyectil = makePicture("Imagenes/Proyectiles/P1.png")
    elif torre == 2:
        vp = 25
        dano = 100
        proyectil = makePicture("Imagenes/Proyectiles/P2.png")
    elif torre == 3:
        vp = 15
        dano = 150
        proyectil = makePicture("Imagenes/Proyectiles/P3.png")
    proyectil.x = xi
    proyectil.y = yi
    proyectil.border = 0
    proyectil.draw(ventanaJ)
    # cuadrática para obtener el tiempo que se tardará el disparo
    a = ve**2-vp**2
    b = 2*dxi*ve
    c = dy**2+dxi**2
    t = (-b+(b**2-4*a*c)**(1/2))/(2*a)
    if t < 0:
        t = (-b-(b**2-4*a*c)**(1/2))/(2*a)
    vpx = dxi/t+ve #velocidad del proyectil en x
    vpy = dy/t #velocidad del proyectil en y
    proyectiles.append([proyectil, vpx, vpy, dano])
# Listas con los enemigos por oleada
enemigos1 = crearEnemigos(5,0,0,0,0,0)
enemigos2 = crearEnemigos(10,0,0,0,0,0)
enemigos3 = crearEnemigos(0,5,0,0,0,0)
enemigos4 = crearEnemigos(5,5,0,0,0,0)
enemigos5 = crearEnemigos(0,7,3,0,0,0)
enemigos6 = crearEnemigos(5,5,5,0,0,0)
enemigos7 = crearEnemigos(2,6,6,2,0,0)
enemigos8 = crearEnemigos(15,0,0,5,0,0)
enemigos9 = crearEnemigos(10,10,10,10,0,0)
enemigos10 = crearEnemigos(0,10,10,0,4,0)
enemigos11 = crearEnemigos(10,0,5,0,8,0)
enemigos12 = crearEnemigos(30,0,0,0,15,0)
enemigos13 = crearEnemigos(15,5,5,5,5,1)
enemigos14 = crearEnemigos(0,0,0,0,0,10)
# Lista que posee las listas de los enemigos
enemigosTodas = [enemigos1, enemigos2, enemigos3, enemigos4, enemigos5, enemigos6, enemigos7, enemigos8, enemigos9, enemigos10, enemigos11, enemigos12, enemigos13, enemigos14]
# Variable temporal que almacena una copia de la lista de enemigos de la oleada actual
enemigosTemp = enemigos1
# Rectángulos que muestran los lugares donde se pueden comprar las torres
rec1 = Rectangle((4, 407), (430, 437))
rec2 = Rectangle((568, 407), (986, 437))
rec3 = Rectangle((4, 628), (986, 658))
# Variable booleana que se activa cuando se acaba de comprar una torre pero no se ha colocado
colocar = False
# Variable booleana que se asigna True cuando hay una oleada en curso
oleadaBool = False
# Variable temporaral con el precio de la útlima torre comprada
tempTorre = 0
# Lista global para almacenar las torres compradas
T1 = []
T2 = []
T3 = []
# Función que actualiza los indicadores principales del juego
def actualizarIndicadores():
    txtOleada.text = str(oleada)
    txtDinero.text = str(dinero)
    txtVidas.text = str(vidas)    
# Función donde se realiza la compra de una torre
def comprar(precio):
    global colocar
    global dinero
    global tempTorre
    if precio <= dinero:
        if oleadaBool == False:
            if precio!= 60:
                rec1.draw(ventanaJ)
                rec2.draw(ventanaJ)
                rec3.draw(ventanaJ)
                txtMensaje.text = "Haz click \n dentro de cualquier \n rectángulo para \n colocar la torre"
                colocar = True
                dinero -= precio
                tempTorre = precio
            else:
                txtMensaje.text = "No puedes comprar \n lluvia de mangualas \n cuando no se está \n ejecutando ninguna oleada"
        else:
            if precio == 60:
                txtMensaje.text = "Haz click en cualquier \n lugar de la pantalla"
                colocar = True
                dinero -= precio
                tempTorre = precio
            else:     
                txtMensaje.text = "No puedes comprar \n torres mientras hay \n una oleada en ejecucion"
    else:
        txtMensaje.text = "No posees suficiente \n dinero para realizar \n la compra"      
# Función que comstruye la torre comprada
def construirTorre(x,y):
    global tempTorre
    if tempTorre == 50:
        torreNueva = makePicture("Imagenes/Torres/T1.png")
        torreNueva.x = x
        torreNueva.y = y
        torreNueva.border = 0
        torreNueva.draw(ventanaJ)
        T1.append(torreNueva)
    elif tempTorre == 150:
        torreNueva = makePicture("Imagenes/Torres/T2.png")
        torreNueva.x = x
        torreNueva.y = y
        torreNueva.border = 0
        torreNueva.draw(ventanaJ)
        T2.append(torreNueva)
    elif tempTorre == 250:
        torreNueva = makePicture("Imagenes/Torres/T3.png")
        torreNueva.x = x
        torreNueva.y = y
        torreNueva.border = 0
        torreNueva.draw(ventanaJ)         
        T3.append(torreNueva)
    elif tempTorre == 60:
        crearLluvia()
        bombas.Play()
    tempTorre = 0
    txtMensaje.text = ""
    rec1.undraw()
    rec2.undraw()
    rec3.undraw()
# Función que crea una lluvia de proyectiles
def crearLluvia():
    for i in range(20, 981, 60):
        proyectil = makePicture("Imagenes/Proyectiles/P4.png")
        proyectil.x = i
        proyectil.y = randint(0,45)
        proyectil.border = 0
        proyectil.draw(ventanaJ)
        proyectiles.append([proyectil, 0, 10, 40])
# Función que inicializa una oleada
def iniciarOleada():
    global ambiente
    ambiente.Close()
    ambiente = makeSound("Musica/MonsterCave.wav")
    ambiente.Play()
    if oleada % 7 == 0:
        gritoMonstruo.Play()
    elif oleada % 5 == 0:
        roar.Play()
    elif oleada % 3 == 0:
        chillidoRatas.Play()
    posicionFila = 1
    for objeto in enemigosTemp:
        objeto[0].border = 0
        objeto[0].x = -(objeto[0].width/2)*(posicionFila)
        objeto[0].y = randint(500, 560)
        objeto[0].draw(ventanaJ)
        posicionFila += 1
# Función que anima los enemigos
def animarEnemigos():
    global vidas
    global oleadaBool
    for objeto in enemigosTemp:
        objeto[0].x += objeto[2]
        if objeto[0].x > 1075:
            objeto[0].undraw()
            objeto[0].x = 0
            vidas -= 1
            enemigosTemp.remove(objeto)
            if len(enemigosTemp) == 0: #verifica si ya no hay objetos en la lista de enemigos debido a que ya todos fueron eliminados al pasar
                oleadaBool = False
                txtMensaje.text = "Fin de la Oleada " + str(oleada)
# Función que detecta enemigos y les dispara con la torre 1
def dispararT1():
    global enemigosTemp
    for torre in T1:
        for enemigo in enemigosTemp:
            if abs(enemigo[0].x - torre.x) <= 100 and abs(enemigo[0].y - torre.y) <= 120: # El número tiene que corresponder al alcance
                crearProyectil(torre.x, torre.y, enemigo[0].x - torre.x, enemigo[0].y - torre.y, enemigo[2], 1)
                cannon3.Play()
                break
# Función que detecta enemigos y les dispara con la torre 2
def dispararT2():
    global enemigosTemp
    for torre in T2:
        for enemigo in enemigosTemp:    
            if abs(enemigo[0].x - torre.x) <= 100 and abs(enemigo[0].y - torre.y) <= 130:
                crearProyectil(torre.x, torre.y, enemigo[0].x - torre.x, enemigo[0].y - torre.y, enemigo[2], 2)
                cannon1.Play()
                break
# Función que detecta enemigos y les dispara con la torre 3
def dispararT3():
    global enemigosTemp
    for torre in T3:
        for enemigo in enemigosTemp:    
            if abs(enemigo[0].x - torre.x) <= 100 and abs(enemigo[0].y - torre.y) <= 140:
                crearProyectil(torre.x, torre.y, enemigo[0].x - torre.x, enemigo[0].y - torre.y, enemigo[2], 3)
                cannon2.Play()
                break
# Función que anima proyectiles
def animarProyectiles():
    global proyectiles     
    for proyectil in proyectiles:
        proyectil[0].x += proyectil[1]
        proyectil[0].y += proyectil[2]
# Función que detecta si un proyectil ya impacto a un enemigo y le resta vida
def impactarEnemigos():
    global proyectiles
    global enemigosTemp
    global oleadaBool
    global dinero
    for proyectil in proyectiles:
        for enemigo in enemigosTemp:
            if abs(proyectil[0].y - enemigo[0].y) < abs(proyectil[2]+1) and abs(proyectil[0].x - enemigo[0].x) < 15: #15 es valor promedio de las velocidades de proyectiles en x
                enemigo[1] -= proyectil[3] 
                if enemigo[1] <= 0:
                    dinero += enemigo[3]
                    enemigo[0].undraw()
                    enemigosTemp.remove(enemigo)
                    if len(enemigosTemp) == 0:
                        oleadaBool = False
                        txtMensaje.text = "Fin de la Oleada " + str(oleada)
                proyectil[0].undraw()
                proyectiles.remove(proyectil)
                break
# Función que elimina los proyectiles que no impactaron a ningún objeto
def eliminarProyectiles():
    global proyectiles
    for proyectil in proyectiles:
        proyectil[0].undraw()
        proyectiles.remove(proyectil) 
# Función para atender los botones del juego
def atenderBoton(boton, evento):
    global oleada
    global oleadaBool
    global enemigosTemp
    global jugando
    global salir
    if boton == botonT1:
        comprar(50)
    elif boton == botonT2:
        comprar(150)
    elif boton == botonT3:
        comprar(250)
    elif boton == botonT4:
        comprar(60)
    elif boton == botonIniciar:
        if oleadaBool == False:
            oleada += 1
            if oleada == 15:
                ganar()
            else:
                enemigosTemp = enemigosTodas[oleada-1]
                oleadaBool = True   
                iniciarOleada()
        else:
            txtMensaje.text = "No se puede iniciar \n una nueva oleada porque \n está una en curso"
    elif boton == botonPlay:
        ventanaMenu.Visible = False
        ventanaJ.Visible = True
    elif boton == botonRegresar:
        ventanaMP.Visible = False
        ventanaMenu.Visible = True
    elif boton == botonMP:
        ventanaMenu.Visible = False
        ventanaMP.Visible = True
        mostrarMP()
    elif boton == botonI:
        ventanaMenu.Visible = False
        ventanaI.Visible = True
    elif boton == botonSalir:
        ventanaMenu.close()
        ventanaJ.close() 
        ventanaMP.close()
        ventanaI.close()
        salir = True
    elif boton == botonRegresar2:
        ventanaI.Visible = False
        ventanaMenu.Visible = True
# Función que se ejecuta cuando el usuario perdió el juego
def perder():
    global vidas
    ambiente.Close()
    ventanaJ. Visible = False
    usuario = ask("Game Over \n Introduce un nombre de usuario para almacenar tu score")
    archivo = open("Textos/MP.txt", "a")
    ventanaMenu.Visible = True
    archivo.write(usuario+","+str(oleada)+"\n")
    botonPlay.Visible = False
    vidas = 10
    archivo.close()
# Función que se ejecuta cuando el usuario ganó el juevo al sobrevivir a las 14 oleadas
def ganar():
    ambiente.Close()
    ventanaJ.Visible = False
    usuario = ask("Ganaste!! \n Introduce un nombre de usuario para almacenar tu score")
    archivo = open("Textos/MP.txt", "a")
    ventanaMenu.Visible = True
    archivo.write(usuario+","+str(oleada)+"\n")
    botonPlay.Visible = False
    archivo.close()
# Función que valida que la torre se coloque en un espacio válido
def esPosicionValida(x, y):
    if (x >= 4 and x <= 430 and y >= 407 and y <= 437) and tempTorre != 60:
        return True
    elif (x >= 568 and x <= 986 and y >= 407 and y <= 437) and tempTorre != 60:
        return True
    elif (x >= 4 and x <= 986 and y >= 628 and y <= 658) and tempTorre != 60:
        return True
    elif tempTorre == 60:
        return True
    else:
        return False
# Función que ordena el archivo de puntajes de mayor a menor
def ordenarPuntajes():
    archivo = open("Textos/MP.txt", "r")
    usuarios = []
    scores = []
    for line in archivo:
        elementos = line.split(",")
        usuarios.append(elementos[0]+",")
        scores.append(int(elementos[1][0:len(elementos[1])-1]))
    archivo.close()
    for i in range (len(scores)):
        for j in range (len(scores)-1):
            if scores[j] <= scores[j+1]:
                tempScore = scores[j+1]
                tempUsuario = usuarios[j+1]
                scores[j+1] = scores[j]
                usuarios[j+1] = usuarios[j]
                scores[j] = tempScore
                usuarios[j] = tempUsuario
    archivo = open("Textos/MP.txt", "w")
    for i in range(len(scores)):
        archivo.write(usuarios[i]+str(scores[i])+"\n")
    archivo.close()     
# Función que muestra los mayores puntajes
def mostrarMP():
    #Imprimir puntajes más altos
    ordenarPuntajes()
    archivo = open("Textos/MP.txt", "r")
    lineas = archivo.readlines()
    archivo.close()
    usuarios = "Usuario\n"
    puntajes = "Oleada Máxima\n"
    for i in range (5):
        elementos = lineas[i].split(",")
        usuarios += elementos[0] + "\n"
        puntajes += elementos[1] + "\n"
    txtPuntajes.text = puntajes
    txtUsuarios.text = usuarios
# Función para atender los clicks del mouse del juego
def atenderMouse(objeto, evento):
    global colocar
    if colocar == True:
        if esPosicionValida(evento.x, evento.y) == True:
            colocar = False
            construirTorre(evento.x, evento.y)
        else:
            txtMensaje.text = "No puedes colocar \n una torre aquí"   
    else:
        pass                   
def main():
    fondoJ = makePicture("Imagenes/Ventanas/Escenario.png")   
    fondoMenu = makePicture("Imagenes/Ventanas/GameMenu.png")
    fondoMP = makePicture("Imagenes/Ventanas/MP.png")
    fondoI = makePicture("Imagenes/Ventanas/Instrucciones.png")
    txtOleada.fontSize = 40
    txtDinero.fontSize = 40
    txtVidas.fontSize = 40
    txtMensaje.fontSize = 24
    txtPuntajes.fontSize = 30
    txtUsuarios.fontSize = 30
    txtOleada.fill = Color("Black")
    txtDinero.fill = Color("Black")
    txtVidas.fill = Color("Black")
    txtMensaje.fill = Color("White")
    txtPuntajes.fill = Color("LightGray")
    txtUsuarios.fill = Color("LightGray")
    rec1.color = Color("Yellow")
    rec2.color = Color("Yellow")
    rec3.color = Color("Yellow")
    rec1.border = 8
    rec2.border = 8
    rec3.border = 8
    rec1.fill = None
    rec2.fill = None
    rec3.fill = None
    fondoJ.draw(ventanaJ)
    fondoMenu.draw(ventanaMenu)
    fondoMP.draw(ventanaMP)
    botonIniciar.draw(ventanaJ)
    fondoI.draw(ventanaI)
    botonT1.draw(ventanaJ)
    botonT2.draw(ventanaJ)
    botonT3.draw(ventanaJ)
    botonT4.draw(ventanaJ)
    txtOleada.draw(ventanaJ)
    txtDinero.draw(ventanaJ)
    txtVidas.draw(ventanaJ)
    txtMensaje.draw(ventanaJ)
    txtPuntajes.draw(ventanaMP)
    txtUsuarios.draw(ventanaMP)
    botonPlay.draw(ventanaMenu)
    botonMP.draw(ventanaMenu)
    botonSalir.draw(ventanaMenu)
    botonRegresar.draw(ventanaMP)
    botonI.draw(ventanaMenu)
    botonRegresar2.draw(ventanaI)
    botonIniciar.connect("click", atenderBoton)
    botonT1.connect("click", atenderBoton)
    botonT2.connect("click", atenderBoton)
    botonT3.connect("click", atenderBoton)
    botonT4.connect("click", atenderBoton)
    botonPlay.connect("click", atenderBoton)
    botonMP.connect("click", atenderBoton)
    botonSalir.connect("click", atenderBoton)
    botonRegresar.connect("click", atenderBoton)
    botonRegresar2.connect("click", atenderBoton)
    botonI.connect("click", atenderBoton)
    ventanaJ.onMouseDown(atenderMouse)
    timer = 0
    while True:
        actualizarIndicadores()
        if oleadaBool == True:
            animarEnemigos()
            if timer == 5:
                dispararT1()
                dispararT2()
                dispararT3()
                timer = 0
            animarProyectiles()
            impactarEnemigos()
            timer += 1
        else:
            eliminarProyectiles()
        ventanaJ.step(0.025)
        if vidas == 0:
            actualizarIndicadores()
            txtMensaje.text = "Game Over"
            if vidas == 0:
                perder()
        if salir == True:
            break
ventanaJ.run(main)

# Pendientes
# Agregar ventanas victoria y almacenar puntos
# Música Menú
# Crashea cuando hay dos usuarios con el mismo nombre
# Referencias