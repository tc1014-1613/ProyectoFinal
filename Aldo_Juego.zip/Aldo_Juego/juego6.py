#encoding: UTF-8
#Aldo Fuentes A01373294
from Graphics import *
from random import randint
import Myro
v = Window("Juego",800,600)
weapon = Picture(1,1, Color("black"))
player = makePicture("jugador.png")
astSpawn = 10
astSpd = 3
astRtn = 3
astCounter = 0.125
lsrSpawn = 2
lsrCounter = 0.875
dft = 7
dftCounter = 0.125
score = 0
lives = 3
pause = True
isOnPause = False
isAlive = True
start = False
displayInstructions = False
#Letreros
gameOver = Text((400,200),"Game Over")
scoreLbl = Text((100,30),"Score "+str(score))
livesLbl = Text((600,30),"Lives ")
highscoreLbl = Text((400,350),"Highscore "+str(score))
pauseLbl = Text((400,300),"Pause")
space = Text((400,200),"SPACE")
shooter = Text((400,300),"SHOOTER")
instructionsLbl = Text((400,250),"Destroy all asteroids.\nD or right key - Move right.\nA or left key - Move left.\nSpace bar - Shoot laser\n(Hold for continous shooting)\nP - Pause game.")
#Botones
instructionsBtn = Button((400,450),"Instructions")
playBtn = Button((350,450),"Play")
resetBtn = Button((360,450),"Play again")
#Listas y diccionarios
lstLaser = []
lstAsteroids = []
lstLives = [] 
astVel = {}
astRot = {}
dicExpCont = {}
dicExpImg = {}
dicActExp = {}
lstExplosions = []
imgExp = [makePicture("explosion-1.png"),makePicture("explosion-2.png"),makePicture("explosion-3.png"),makePicture("explosion-4.png"),makePicture("explosion-5.png")]
def updateScore(): #Actualiza el puntaje
    global scoreLbl
    scoreLbl.undraw()
    scoreLbl = Text((100,30),"Score "+str(score))
    scoreLbl.fill = Color("White")
    scoreLbl.fontSize = 40
    scoreLbl.draw(v)
def createBodyExplosion(asteroid):#Crea un cuerpo sobre el que se animara la explosion
    cuerpo = Circle((asteroid.x-60,asteroid.y-60),50)
    cuerpo.fill = None
    cuerpo.border = 0
    cuerpo.draw(v)
    lstExplosions.append(cuerpo)
    dicExpImg[cuerpo] = 1
    dicExpCont[cuerpo] = .2
    dicActExp[cuerpo] = imgExp[0]
    if lives < 0:
        dicActExp[cuerpo] = makePicture("explosion-1.png")
        dicActExp[cuerpo].scale(3)
    dicActExp[cuerpo].border = 0
    dicActExp[cuerpo].draw(cuerpo)
def deleteAsteroid(asteroid):#Borra el asteroide de la ventana, las listas y diccionarios
    del astVel[asteroid]
    del astRot[asteroid]
    lstAsteroids.remove(asteroid)
    asteroid.undraw()
def animateLasers():#Mueve cada proyectil hacia arriba y los borra si se salen de la ventana
    for lsr in lstLaser:
        lsr.y -= 10
        if lsr.y < 0:
            lstLaser.remove(lsr)
            lsr.undraw()
def animateAsteroids():#Mueve cada asteroide hacia abajo y lo borra si se sale de la ventana
    global isAlive
    for asteroid in lstAsteroids:
        asteroid.y += astVel[asteroid]
        asteroid.rotate(astRot[asteroid])
        if asteroid.y > 700:
            deleteAsteroid(asteroid)
            if isAlive == True:
                isAlive = False
                gameOverLogic()
def animateExplosions():#Anima las explosiones dibujando un ciclo de imagenes en el cuerpo creado en la colision.
    for n in lstExplosions:
        if dicExpCont[n]%1==0:
            dicActExp[n].undraw()
            del dicActExp[n]
            dicActExp[n] = imgExp[dicExpImg[n]]
            if lives < 0:
                dicActExp[n] = makePicture("explosion-"+str(dicExpImg[n])+".png")
                dicActExp[n].scale(3)
            dicActExp[n].border = 0
            dicActExp[n].draw(n)
            dicExpImg[n] += 1
            dicExpCont[n] = .2
            if dicExpImg[n] > 4:
                n.undraw()
                del dicExpImg[n]
                del dicExpCont[n]
                lstExplosions.remove(n)
        else:
            dicExpCont[n] += .2
def gameOverLogic():#Esconde los elementos en pantalla cuando pierde y muestra el puntaje mximo
    global highscoreLbl, isAlive
    if isAlive == False:
        player.y = 800
        weapon.y = player.y
        gameOver.draw(v)
        livesLbl.y = -100
        scoreLbl.x = 400
        scoreLbl.y = 350
        resetBtn.Visible = True
        entrada = open("highscore.txt","r")
        highscore = int(entrada.readline())
        entrada.close()
        if score > highscore:
            salida = open("highscore.txt","w")
            salida.write(str(score))
            salida.close()
            highscoreLbl = Text((400,300),"Highscore "+str(score))
        else:
            highscoreLbl = Text((400,300),"Highscore "+str(highscore))
        highscoreLbl.fill = Color("white")
        highscoreLbl.fontSize = 40
        highscoreLbl.draw(v)
        resetBtn.connect("click",restartGame)
        for live in lstLives:
            live.y = -30
        while len(lstLaser)>0:
            for lsr in lstLaser:
                lsr.undraw()
                lstLaser.remove(lsr)
def restartGame(btn,e):#Reinicia el juego quitando los elementos de gameOverLogic y poniendo los objetos en sus posiciones iniciales
    global score, lives
    if btn==resetBtn:
        gameOver.undraw()
        highscoreLbl.undraw()
        score = 0
        lives = 3
        while len(lstAsteroids)>0:
            for asteroid in lstAsteroids:
                deleteAsteroid(asteroid)
        initialConfiguration()
def initialConfiguration():#Pone los objetos en sus posiciones iniciales para empezar a jugar
    global scoreLbl, isAlive, pause, astSpawn
    pause = False
    isAlive = True
    resetBtn.Visible = False
    player.x = 400
    player.y = 600-50
    weapon.x = player.x
    weapon.y = player.y
    updateScore()
    astSpawn = 10
    livesLbl.y = 30
    for live in lstLives:
        live.y = 30
def showInstructions(btn,e):#Dibuja las instrucciones del juego en la ventana
    global displayInstructions
    if displayInstructions == False:
        displayInstructions = True
        instructionsLbl.draw(v)
        space.undraw()
        shooter.undraw()
        highscoreLbl.undraw()
        playBtn.Visible = False
    elif displayInstructions == True:
        displayInstructions = False
        instructionsLbl.undraw()
        space.draw(v)
        shooter.draw(v)
        highscoreLbl.draw(v)
        playBtn.Visible = True
def startGame(btn,e):#Cambia las variables para empezar el juego
    global pause, start
    if btn == playBtn:
        pause = False
        start = True
def mainMenu():#Dibuja los elementos del menu principal
    global highscoreLbl
    background = makePicture("fondo.jpg")
    background.draw(v)
    space.fill = Color("white")
    space.fontSize = 100
    shooter.fill = Color("white")
    shooter.fontSize = 100
    space.draw(v)
    shooter.draw(v)
    playBtn.draw(v)
    playBtn.Visible = True
    instructionsBtn.draw(v)
    instructionsBtn.Visible = True
    entrada = open("highscore.txt","r")
    highscore = int(entrada.readline())
    entrada.close()
    highscoreLbl = Text((400,400),"Highscore "+str(highscore))
    highscoreLbl.fill = Color("white")
    highscoreLbl.fontSize = 40
    highscoreLbl.draw(v)
    playBtn.connect("click",startGame)
    instructionsLbl.fill = Color("white")
    instructionsLbl.fontSize = 40
    instructionsBtn.connect("click",showInstructions)                                                                                                              
def setGame():#Comienza el juego borrando los elementos del menu principal y dibuja los elementos en sus posiciones iniciales
    global start
    start = False
    space.undraw()
    shooter.undraw()
    highscoreLbl.undraw()
    playBtn.Visible = False
    instructionsBtn.Visible = False
    resetBtn.draw(v)
    gameOver.fill = Color("white")
    gameOver.fontSize = 100
    player.scale(.25)
    player.border = 0
    scoreLbl.fill = Color("White")
    scoreLbl.fontSize = 40
    pos = 670
    for n in range(1,4):
        live = makePicture("jugador.png")
        live.border = 0
        live.x = pos
        live.scale(.1)
        live.draw(v)
        lstLives.append(live)
        pos += 50     
    initialConfiguration()
    player.draw(v)
    scoreLbl.draw(v)
    livesLbl.fill = Color("white")
    livesLbl.fontSize = 35
    livesLbl.draw(v)
    weapon.border = 0
    weapon.draw(v)
    pauseLbl.fill = Color("yellow")
    pauseLbl.fontSize = 100
def spawnAsteroids():#Reaparece asteroides cada cierto tiempo
    global astCounter 
    if astCounter%astSpawn==0:
        aN = "asteroide-" + str(randint(1,4)) + ".png"
        asteroide = makePicture(aN)
        asteroide.border = 0
        asteroide.scale(randint(50,80)/100)
        asteroide.x = randint(100,700)
        asteroide.y = -100
        asteroide.draw(v)
        lstAsteroids.append(asteroide)
        astVel[asteroide] = randint(2,astSpd)
        astRot[asteroide] = randint(-astRtn,astRtn)
        astCounter = .125
    else:
        astCounter += .125
def detectCollisions():#Visita todos los elementos de la lista de asteroides y de lasers para detectar colisiones entre ellos. Y crea un cuerpo en la colision para correr la animacion.
    global score, lives, isAlive
    for asteroide in lstAsteroids:
        for proyectil in lstLaser:
            if abs(asteroide.x - proyectil.x)< 50 and abs(asteroide.y - proyectil.y)<50:
                deleteAsteroid(asteroide)
                createBodyExplosion(asteroide)
                lstLaser.remove(proyectil)
                proyectil.undraw()
                score += 1
                updateScore()
                Myro.play("explosion.wav")
    for asteroide in lstAsteroids:
        if abs(asteroide.x-player.x)<65 and abs(asteroide.y-player.y)<60:
            deleteAsteroid(asteroide)
            lives -= 1
            if lives >= 0:
                lstLives[lives].y = -30
            else:
                isAlive = False
                gameOverLogic()
            createBodyExplosion(asteroide)
            Myro.play("explosion2.wav")
def increaseDifficulty():#Disminuye el tiempo de reaparicion de los asteroides
    global dftCounter, astSpawn
    if dftCounter%dft==0:
        dftCounter = .125
        if astSpawn>3:
            astSpawn -= .125
    else:
        dftCounter += .125
def main():
    global pause, isOnPause, lsrCounter
    mainMenu()
    while True:
        v.step(0.001)
        if start == True:
            setGame()
        if getKeyPressed("p"):#Cambia el valor de pause para pausar el juego
            if pause == False:
                pause = True
            elif pause == True:
                pause = False
            if isOnPause == False:
                isOnPause = True
            v.step(.25)   
        if pause == False:
            if lives >= 0:
                if isOnPause == True:
                    isOnPause = False
                    pauseLbl.undraw()
                if (getKeyPressed("Right") or getKeyPressed("d")) and not (getKeyPressed("Left") or getKeyPressed("a")):#Movimiento del jugador a la derecha
                    player.move(10,0)
                    weapon.x += 10
                if (getKeyPressed("Left") or getKeyPressed("a"))and not (getKeyPressed("Right") or getKeyPressed("d")):#Movimiento del jugador a la izquierda
                    player.x -= 10
                    weapon.x -= 10
                if getKeyPressed("space"): #Crear disparos al oprimir la tecla espacio
                    if lsrCounter%lsrSpawn==0 and isAlive == True:
                        newLsr = Picture(5,10, Color("Red"))
                        newLsr.border = 0
                        newLsr.scale(1.5)
                        newLsr.x = weapon.x
                        newLsr.y = weapon.y
                        newLsr.draw(v)
                        lstLaser.append(newLsr)
                        lsrCounter = 0.125
                        Myro.play("laserBlast.wav")
                    else:
                        lsrCounter += .125
                if not getKeyPressed("space"):
                    lsrCounter = lsrSpawn
            spawnAsteroids()
            animateAsteroids()
            animateLasers()
            detectCollisions()
            animateExplosions()
            increaseDifficulty()
        else:
            if isOnPause == True:
                isOnPause = False
                pauseLbl.draw(v)
v.run(main)