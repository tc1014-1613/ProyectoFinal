from Graphics import *  
import math
import Myro
import random
#-------------INIT VARS------------------
score = 0
hiscore = 0
readhiscore = open("readhiscore.txt","r")
hiscore = int( readhiscore.readline())
readhiscore.close()

#--------------WINDOW STUFF--------------
room_width = 640
room_height = 360

v = Window("YOURE A SPACE PERSON THAT GOES PEW PEW...",room_width,room_height)
v1 = Picture("imgRef.png")
v2 = Picture("imgRef.png")

v1.x = 0 
v1.y = 0
v1.draw(v)

v2.x = 0 
v2.y = 0
v2.draw(v1)
shake = 0
levelState = "Title"
#--------------MENU STUFF--------------
Title = Picture("title.png")
Title.border = 0
Title.x = room_width/2
Title.y = room_height/3
Title.draw(v)

PressE = Picture("presswasd.png")
PressE.border = 0

PressE.x = room_width/2
PressE.y = room_height-80
PressE.draw(v)

ScoreBanner = Picture("score.png")
ScoreBanner.border = 0
ScoreBanner.x = 45
ScoreBanner.y = 15
ScoreBanner.draw(v1)

Score = Text((100,15),str(score))
Score.color = Color("White")
Score.draw(v1)

HScoreBanner = Picture("hscore.png")
HScoreBanner.border = 0
HScoreBanner.x = 70
HScoreBanner.y = 35
HScoreBanner.draw(v1)

HScore = Text((145,35),str(hiscore))
HScore.color = Color("White")
HScore.draw(v1)
#-------------SCORES------------------
def updateScore():
    global Score
    global score
    global hiscore
    global HScore
    if hiscore <= score:
        hiscore = score
    Score.undraw()
    Score = Text((100,15),str(score))
    Score.color = Color("White")
    Score.draw(v1)
    HScore.undraw()
    HScore = Text((145,35),str(hiscore))
    HScore.color = Color("White")
    HScore.draw(v1)
    
    readhiscore = open("readhiscore.txt","w")
    readhiscore.write(str(hiscore))
    readhiscore.close()
#--------------PLAYER STUFF--------------

player_control = Picture("imgRef.png")
player_image = Picture("player\P1_IR0.png")

player_image.draw(player_control)
player_control.x = room_width/2
player_control.y = room_height/2 + 25

player_control.scale(1)
player_control.draw(v1)

player_direction = "Left"
image_cicle = 0
image_index = 0

maxSpeed = 2

#--------------AIM STUFF--------------
player_sight = Picture("sCrossHairs.png")
player_sight.border = 0
player_sight.draw(v1)

#-------------BULLETS STUFF--------------
bulletList = []
flashList = []
DflashList = []
def moveBullet():
    for b in bulletList:   
        b.forward(random.randint(12,15))
        if (b.x < -100 or b.x > room_width+100) or (b.y < -100 or b.y > room_height+100):
            b.undraw()
            bulletList.remove(b)
              
def flashFlash():
    for f in flashList:
        f.scaleFactor+=0.5
        f.moveTo(player_control.x+17,player_control.y+14)
        if f.scaleFactor > 2:
            f.undraw()
            flashList.remove(f)       
        
def shootBullet(v,event):
    if levelState == "Game" and len(bulletList) < 2:
        global shake
        shake = 15
        
        sightCoord = getMouseNow()
        player_sight.moveTo(sightCoord[0],sightCoord[1])
        player_sight.draw(v1)

        dir_x = sightCoord[0] - player_control.x-11 
        dir_y = sightCoord[1] - player_control.y-12 

        rads = math.atan2(dir_y,dir_x)
        degs = math.degrees(rads)
        if degs > 0:
            degs =360-degs
        if degs <= 0:
            degs =abs(degs)  
                    
        bullet = Picture("bullet1.png")
        bullet.border = 0
        bullet.x = player_control.x+11 
        bullet.y = player_control.y+14
        bullet.rotate(degs)
        bullet.draw(v1)
        bulletList.append(bullet)
        
        flash = Circle((player_control.x+11,player_control.y+14),10)
        flash.border = 0
        flash.fill = Color(255,255,200)
        flash.draw(v1)
        flashList.append(flash)
        Myro.play("gun1.wav")
    
  
onMouseDown(shootBullet)    
#----------GUN-----------
Gun = Picture("sGun1.png")
Gun.setX(5)
Gun.setY(0)
Gun.border = 0
Gun.draw(v1)         

#----------PLAYER SHADOW-----------
Shadow = Picture("P_Shadow.png")
Shadow.border = 0
Shadow.draw(v1)
#-------------ENEMY STUFF--------------
enemyList = []
enemyDict = {}

def spawnEnemy():

        enemy_control = Picture("imgRef.png")
        enemy_control.border = 0
        enemy_picture = Picture("enemy\E1_RR0.png")
        enemy_picture.border = 0 
        
        choose =int(random.randint(1,4))
        if choose == 1:
            enemy_control.x = random.randint(-60,700)
            enemy_control.y = -50
        if choose == 2:
            enemy_control.x = random.randint(-60,700)
            enemy_control.y = 410
        if choose == 3:
            enemy_control.x = -50
            enemy_control.y = random.randint(-60,420)
        if choose == 4:
            enemy_control.x = room_width+50
            enemy_control.y = random.randint(-60,420)
            
        enemy_control.draw(v1)
        enemyList.append(enemy_control)
        enemyDict[enemy_control] = enemy_picture
        
def moveEnemy():
    global score
    global image_cicle
    global image_index
    
    for enemy_control in enemyList: 
    
        if levelState != "gameOver": 
            dir_x =  player_control.x+14 - enemy_control.x 
            dir_y =  player_control.y+16 - enemy_control.y
            
        if levelState == "gameOver":
            dir_x =  player_control.x+14 - (-500)
            dir_y =  player_control.y+16 - (180)
            
        rads = math.atan2(dir_y,dir_x)
        degs = math.degrees(rads)
        if degs > 0:
            degs =360-degs
        if degs <= 0:
            degs =abs(degs) 
    
        enemy_picture = enemyDict[enemy_control]  
        enemy_control.rotateTo(-degs)
        enemy_control.forward(2)
        enemy_picture.border = 0
            
        enemy_picture.rotateTo(degs) 
        enemy_picture.draw(enemy_control)  
                 
                
        for bullet in bulletList:                                
            if abs(bullet.x - enemy_control.x) < 30 and abs(bullet.y - enemy_control.y) < 30:
                enemy_control.y = -10001
                bullet.undraw()
                bullet.x = 1000
                score +=10
                updateScore()
                    
        if enemy_control.y < -1000:
            choose = random.randint(1,2)
            if choose == 1:
                Myro.play("DeathE1.wav")
            if choose == 2:
                Myro.play("DeathE2.wav")
            enemy_control.undraw()
            enemyList.remove(enemy_control)
            enemyDict.pop(enemy_control)
            
  #-------------MINI DEATH ANIMATION--------------   
def deathFlash(): 
    for f in DflashList:
        f.scaleFactor+=3
        f.moveTo(player_control.x+17,player_control.y+14)
        if f.scaleFactor > 500: 
            f.undraw()
            DflashList.remove(f)
            
            restartGame()
#-------------RESTART--------------   
def restartGame(): 
    global levelState
    global player_control 
    global player_image  
    global score  
    global hiscore
    
    levelState = "Title" 
    score = 0
    updateScore()
                
    player_control.x = room_width/2
    player_control.y = room_height/2 + 25

    player_control.scale(1)
    player_control.draw(v1)
    player_image.draw(player_control)
    
    Title.x = room_width/2
    Title.y = room_height/3
    
    PressE.x = room_width/2
    PressE.y = room_height-80
    
    for enemy_control in enemyList: 
        enemy_control.y = -10001 
    
           
    
                      
 #-------------MAIN--------------   
def main():
    bg = Picture("bg1.png")
    bg.x = room_width/2 - 25
    bg.y = room_height/2 - 25
    bg.scale(1.25)
    while True:
        bg.draw(v2)
        moveEnemy()
        moveBullet()
        flashFlash()
        deathFlash()
        
        
        global levelState
        
        
        global player_control 
        global player_image
        global player_direction
        
        
        global image_cicle
        global image_index
        
        global player_sight
        global maxSpeed
        
        global shape
        global bullet
        global Gun
        global Shadow
        global shake
        
        global Title
        global PressE
#--------------MENU--------------  
        if levelState == "Game":
            if Title.y > -100:
                Title.y -= 8
            if PressE.y < 740:
                PressE.y += 8
#--------------ENEMIES-------------- 
        if levelState == "Game":
        
            spawnNum = int(random.randint(1,250))
            if (spawnNum < 5) and len(enemyList) < 10:
                spawnEnemy()
                                                          
#--------------PLAYER SIGHT--------------        

        sightCoord = getMouseNow()
        player_sight.moveTo(sightCoord[0],sightCoord[1])
        player_sight.draw(v1)

        dir_x = sightCoord[0] - player_control.x+11 
        dir_y = sightCoord[1] - player_control.y+12 

        rads = math.atan2(dir_y,dir_x)
        degs = math.degrees(rads)
        if degs > 0:
            degs =360-degs
        if degs <= 0:
            degs = abs(degs)  
         
        Gun.moveTo(player_control.x+15,player_control.y+16)
        
        if levelState != "gameOver":
            Gun.rotateTo(-degs)                 
            Gun.draw(v1)
        else:
            Gun.undraw()
        if levelState != "gameOver":
            Shadow.moveTo(player_control.x+16,player_control.y+18)      
            Shadow.draw(v1)
        if levelState == "gameOver":
            Shadow.undraw()         

#--------------CICLES TROUGH IMAGES--------------        
        if image_cicle < 6:
            image_cicle += 1/4
        else:
            image_cicle = 0
            
        if image_cicle == math.floor(image_cicle):
            image_index = image_cicle
            
                
        #FOUR DIRECTIONS
        
        if player_control.x <= sightCoord[0]:
            player_direction = "Right"
        if player_control.x > sightCoord[0]:
            player_direction = "Left"
            
 #--------------SCREENSHAKE-------------- 
        if shake > 0:
            v1.x=random.randint(-shake,shake)
            v1.y=random.randint(-shake,shake)
            shake -=2
        else:
            
            v1.x = 0
            v1.y = 0 
            shake = 0
#--------------START--------------        
        if levelState == "Title" and getKeyPressed("e"):
            levelState = "Game"               
#--------------MOVE LEFT--------------
        if levelState == "Game":
            if getKeyPressed("a") and not getKeyPressed("d"):
            
                player_control.move(-speed,0)
                if speed < maxSpeed:
                    speed+=0.25
                if (image_cicle == round(image_cicle)):
                    player_image.undraw()
                    if player_direction == "Right":
                        player_image = Picture("player\P1_RR"+("%i"%image_index)+".png")
                    if player_direction == "Left":
                        player_image = Picture("player\P1_RL"+("%i"%image_index)+".png")

                player_image.border = 0
                player_image.draw(player_control) 
                
    #--------------MOVE RIGHT--------------                  
            if getKeyPressed("d") and not getKeyPressed("a"):
                player_control.move(speed,0)
                if speed < maxSpeed:
                    speed+=0.25            
                if (image_cicle == round(image_cicle)):
                    player_image.undraw()
                    if player_direction == "Right":
                        player_image = Picture("player\P1_RR"+("%i"%image_index)+".png")
                    if player_direction == "Left":
                        player_image = Picture("player\P1_RL"+("%i"%image_index)+".png")

                player_image.border = 0
                player_image.draw(player_control) 
                            
    #--------------MOVE UP-------------- 
            if getKeyPressed("w"):
                player_control.move(0,-speed*0.8)
                if speed < maxSpeed:
                    speed+=0.25            
                if (image_cicle == round(image_cicle)):
                    player_image.undraw()
                    if player_direction == "Right":
                        player_image = Picture("player\P1_RR"+("%i"%image_index)+".png")
                    if player_direction == "Left":
                        player_image = Picture("player\P1_RL"+("%i"%image_index)+".png")
                player_image.border = 0
                player_image.draw(player_control)     
     #--------------MOVE DOWN-------------- 
            if getKeyPressed("s"):
                player_control.move(0,speed*0.8)
                if speed < maxSpeed:
                    speed+=0.25            
                if (image_cicle == round(image_cicle)):
                    player_image.undraw()
                    if player_direction == "Right":
                        player_image = Picture("player\P1_RR"+("%i"%image_index)+".png")
                    if player_direction == "Left":
                        player_image = Picture("player\P1_RL"+("%i"%image_index)+".png")
                player_image.border = 0
                player_image.draw(player_control) 
                                        
                                                                     
#--------------STANDING STILL--------------
        if (not getKeyPressed("a") and not getKeyPressed("d") and not getKeyPressed("w") and not getKeyPressed("s")) or (getKeyPressed("a") and getKeyPressed("d")):         
            if (image_cicle == round(image_cicle)):
                player_image.undraw()
                if player_direction == "Left":
                    player_image = Picture("player\P1_IL"+("%i"%image_index)+".png")
                if player_direction == "Right":
                    player_image = Picture("player\P1_IR"+("%i"%image_index)+".png")
            player_image.border = 0
            player_image.draw(player_control)
            speed = 0  
#--------------DYING--------------            
            for enemy_control in enemyList:
                if abs(player_control.x - enemy_control.x) < 30 and abs(player_control.y - enemy_control.y) < 30:
                    if levelState != "gameOver":
                        Myro.play("DeathP1.wav")
                        levelState = "gameOver"
                        Dflash = Circle((player_control.x+11,player_control.y+14),15)
                        Dflash.border = 0
                        Dflash.fill = Color("White")
                        Dflash.draw(v1)
                        DflashList.append(Dflash)  
                                                  
        v.step(0.01)
        
   
        

v.run(main)
