#encoding: UTF-8
#Autor: Jesus Perea
#Videojuego

from Graphics import *    #exportamos toda la libreria Graphics
from time import sleep
from random import randint

#Variables Globales
v = Window("Four Elements",800,600)   #Genera una ventana
v.mode = "physics"                    #Establece gravedad al juego
#Fondo del juego
fondoNivel = makePicture("Imagenes/fondoExtendido.jpg")    
fondoNivel2 = makePicture("Imagenes/fondoExtendido.jpg")    
#Fondo de la historia
fondoHistoria1 = makePicture("Imagenes/fondoHistoria1.png") 
#Personaje:
fuego = makePicture("Imagenes/Fuego.png")
#piso
piso = makePicture("Imagenes/Base de piso Completo.png")
vida1 = makePicture("Imagenes/Vida.png")
vida2 = makePicture("Imagenes/Vida.png")
vida3 = makePicture("Imagenes/Vida.png")
vida = 4
listaSD = []
soldado = makePicture("Imagenes/Soldier.png")
puntaje = 0
puntos = Text((750,50),str(puntaje))
puntos.fill = Color("white")
puntos.fontSize = 50
listaPun = []
listaPun.append(puntos)
perdiste = makePicture("Imagenes/Perdiste.png")
perdiste.bodyType = "static"
perdiste.x = 400
ganaste = makePicture("Imagenes/Ganaste.png")
ganaste.bodyType = "static"
ganaste.x = 400
instrucciones = makePicture("Imagenes/Instrucciones.png")

def leerTecla(ventana,evento):
    tecla = evento.key
    if fuego.y < 350:
        tecla = "Space"
    if tecla == "space":
        fuego.y -= 30
    
        
def animarSoldado():
    for soldado in listaSD:
        soldado.x -= randint(10,20)

def animarFondo(): 
    fondoNivel.x -= 10
    fondoNivel2.x -= 10
    if fondoNivel.x == -100:
        fondoNivel2.x = 1600
     
    if fondoNivel2.x == -100:
        fondoNivel.x = 1600

def quitarVidas():
    global vida
    global puntaje
    global puntos
    for soldado in listaSD:
        if fuego.y > 350 and soldado.x < 101 and soldado.x >50:
            vida -= 1 
            if vida == 3:
                if fuego.y > 350 and soldado.x < 101 and soldado.x >50:
                    vida3.undraw()
                    listaSD.remove(soldado)
                    soldado.undraw()
            elif vida == 2:
                if fuego.y > 350 and soldado.x < 101 and soldado.x >50:
                    vida2.undraw()
            elif vida == 1:
                if fuego.y > 350 and soldado.x < 101 and soldado.x >50:
                    vida1.undraw()
                    fuego.undraw()
        else:
            if soldado.x < 100 and soldado.x > 90:
                puntaje += 100
                print(puntaje)
                puntos.undraw()
                puntos2 = Text((750,50),str(puntaje))
                puntos2.fill = Color("white")
                puntos2.fontSize = 50
                puntos2.draw(v)
                puntos2.removeFromPhysics()
                listaPun.append(puntos2)
                listaPun.remove(puntos)
                for puntos in listaPun:
                    puntos.draw(v)
                    puntos.removeFromPhysics()

def main():
    #Fondo de la historia
    fondoHistoria1.removeFromPhysics()
    fondoHistoria1.draw(v)  #Dibuja la primera parte de la histora
    sleep(4)
    
    #Instrucciones
    instrucciones.removeFromPhysics()
    instrucciones.draw(v)
    sleep(4)
    instrucciones.undraw()
    
    #Fondo de Nivel
    fondoHistoria1.undraw()
    fondoNivel.draw(v)
    fondoNivel2.draw(v)
    puntos.draw(v)
    puntos.removeFromPhysics()
    
    #fondoNivel2.x = 2000
    fondoNivel2.removeFromPhysics()
    fondoNivel.removeFromPhysics()
    sleep(1)
    
    #fondoNivel.undraw()
    vida1.x = 50
    vida1.y = 50
    vida1.border = 0
    vida1.draw(v)
    vida1.removeFromPhysics()
        
    vida2.x = 100
    vida2.y = 50
    vida2.border = 0
    vida2.draw(v)
    vida2.removeFromPhysics()

    vida3.x = 150
    vida3.y = 50
    vida3.border = 0
    vida3.draw(v)
    vida3.removeFromPhysics()
    
    piso.y = 550
    piso.draw(v)
    piso.bounce = 0
    piso.bodyType = "static"
    sleep(1)
    
    #Personaje
    fuego.x = 100
    fuego.y = 405
    fuego.border = 0
    fuego.bounce = 0
    fuego.draw(v)
    
    #Soldado
    soldado = makePicture("Imagenes/Soldier.png")
    soldado.y = 405
    soldado.x = 600#randint(600,2000)   
    soldado.border = 0
    soldado.draw(v)
    soldado.removeFromPhysics()
    listaSD.append(soldado)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(650,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)

    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(700,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(750,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)

    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(800,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)

    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(850,2000)   
    soldado2.border = 0 
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)

    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(900,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(950,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(1000,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(1050,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(1100,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Soldado
    soldado2 = makePicture("Imagenes/Soldier.png")
    soldado2.y = 405
    soldado2.x = randint(1150,2000)   
    soldado2.border = 0
    soldado2.draw(v)
    soldado2.removeFromPhysics()
    listaSD.append(soldado2)
    
    #Eventos del teclado
    onKeyPress(leerTecla)
    
    
    
    #Ciclo del juego
    while True:     #Cliclo Infinito
        v.step(0.025)      #Se repite 400 veces por segundo
        animarFondo()
        animarSoldado()
        quitarVidas()  
        if vida == 1:
            perdiste.draw(v)
            fuego.undraw() 
        if puntaje >= 800:
            ganaste.draw(v)
            fuego.undraw()
            
v.run(main)