#encoding: UTF-8
#Karla Valeria Alcantara Duarte

from Graphics import *
from Myro import *

v = Window("Space Invaders",1200,700)
spaceship = makePicture("spaceship.gif")

#Incremento (velocidad) de cada villano
incVillano1 = 40 
incVillano2 = 45
incVillano3 = 50

bullet = makePicture("bullet.png")

listaBalas = []
listaVillanos = []

puntaje = 0
balas = 10

intentos = 0
numeroIntentos = Text((600,150),"Veces jugadas:"+str(intentos))

#Boton de reinicio
btnReset = Button((600,250),"Reset")
btnReset.draw(v)
btnReset.Visible= False

#Boton de inicio
btnStart = Button((600,450),"Start")
btnStart.draw(v)
btnStart.Visible = False

#Etiqueta de puntaje
puntajee = Text((100,40),"Puntaje:")
puntajee.fontSize = 20
puntajee.fill = Color("White")

#Etiqueta de balas
eBalas = Text((95,20),"Balas:")
eBalas.fontSize = 20
eBalas.fill = Color("White")

#Etiqueta inicio 
inicioJuego = Text((600,350),"Space Invaders")
inicioJuego.fontSize = 40
inicioJuego.fill = Color("White")

#Instrucciones
instrucciones = Text((200,400),"Space bar = shoot\nLeft Key = move to left\nRight Key = move to right")
instrucciones.fontSize = 20
instrucciones.fill = Color("White")

#Etiquetas fin del juego
finJuego = Text((600,350),"Game Over")
finJuego.fontSize = 40
finJuego.fill = Color("White")

estado = False


def leerTecla(ventana, evento):
    tecla = evento.key
    if tecla=="Right":
        spaceship.x += 20
    elif tecla=="Left":
        spaceship.x -= 20
    
    elif tecla=="space":
        global balas
        newBullet = makePicture("bullet.png")
        newBullet.border = 0
        newBullet.x = spaceship.x
        newBullet.y = spaceship.y
        newBullet.draw(v)
        listaBalas.append(newBullet)
        balas -= 1
        play("lasser.wav")
        
def animarVillano(villano1):
    global incVillano1
    villano1.x += incVillano1
    if villano1.x>=1200-45 or villano1.x<=45:
        incVillano1 *= -1
        
def animarVillano2(villano2):
    global incVillano2
    villano2.x += incVillano2
    if villano2.x>=1200-45 or villano2.x<=45:
        incVillano2 *= -1
        
def animarVillano3(villano3):
    global incVillano3
    villano3.x += incVillano3
    if villano3.x>=1200-45 or villano3.x<=45:
        incVillano3 *= -1
        
def animarBalas():
    for bullet in listaBalas:
        bullet.y -= 20 
        if bullet.y <0:
            listaBalas.remove(bullet)
            bullet.undraw()

def quitarVillanos(listaVillanos,listaBalas): 
    global puntaje                       
    for newBullet in listaBalas:
        for villano in listaVillanos:
            if (newBullet.x >= villano.x-(0.5*villano.width) and newBullet.x<= villano.x+(0.5*villano.width)) and (newBullet.y >= villano.y-(0.5*villano.height) and newBullet.y <= villano.y+(0.5*villano.height)):
                puntaje += 15
                villano.undraw()
                newBullet.undraw() 
                play("crash.wav") 
                print(puntaje)
                listaVillanos.remove(villano)
                listaBalas.remove(newBullet) 
                break                
                
def pierde():
    global balas
    global estado
    if balas==0:
        estado == True
        return estado
         
def gameOver():
    global estado
    global intentos
    if balas==0 or puntaje==45:
        puntajee.undraw()
        eBalas.undraw()
        finJuego.draw(v)
        intentos += 1
        mostrarBotonReset(True)
        #escribirArchivo()
        entrada = open("numIntentos.txt","r")
        veces = entrada.readline()
        entrada.close()  
        if intentos > int(veces):
            sale = open("numIntentos.txt","w") 
            sale.write(str(intentos))
            sale.close
            numeroIntentos = Text((600,150),"Veces jugadas:"+str(intentos))
            numeroIntentos.fill = Color("White")
            numeroIntentos.fontSize = 30
            numeroIntentos.draw(v)
        
        while len(listaBalas)>0:
            for bala in listaBalas:
                bala.undraw()
                listaBalas.remove(bala)
        if len(listaVillanos)>0:
            for villano in listaVillanos:
                villano.undraw()
        btnReset.connect("click",atenderBotonReset)
        estado = True
        return estado
                    
def gana():
    global estado
    global puntaje
    if puntaje==45:
        estado == True 
        return estado     

def mostrarBotonStart():
    global estado
    if not estado:
        btnStart.Visible = True
            
    
def mostrarBotonReset(estado):
    btnReset.Visible = estado
        
def atenderBoton(boton,evento):
    global estado
    if boton==btnStart:
        mostrarBotonStart()
        estado = True
        
        
def atenderBotonReset(boton,evento):
    global puntaje, balas
    if boton==btnReset:
        mostrarBotonReset(True)
        puntaje = 0
        balas = 10 
        finJuego.undraw()
        numeroIntentos.undraw()
        btnReset.Visible = False
        while len(listaBalas)>0:
            for bala in listaBalas:
                listaBalas.remove(bala)
        resetGame()
        
        
def resetGame(): 
    
    puntajee.draw(v)
    eBalas.draw(v)
    #Spaceship
    spaceship.border = 0
    spaceship.x = 600-15
    spaceship.y = 670-30
    spaceship.draw(v)
    #Bala
    bullet.x = spaceship.x
    bullet.y = spaceship.y
    bullet.border = 0
    bullet.draw(v)
    #Villanos
    #Villano 1
    villano1 = makePicture("Villano.png")
    villano1.x = 600
    villano1.y = 200
    villano1.border = 0
    villano1.draw(v)
    listaVillanos.append(villano1)
    #Villano 2
    villano2 = makePicture("Villano2.png")
    villano2.x = 600
    villano2.y = 100-5
    villano2.border = 0
    villano2.draw(v)
    listaVillanos.append(villano2)
    #Villano 3
    villano3 = makePicture("Villano3.png")
    villano3.x = 600
    villano3.y = 300
    villano3.border = 0
    villano3.draw(v)
    listaVillanos.append(villano3)

def main():
    mostrarBotonStart()
    mostrarBotonReset(estado)
    fondo = makePicture("Background.jpg")
    fondo.draw(v)
    #Spaceship
    spaceship.border = 0
    spaceship.x = 600-15
    spaceship.y = 670-30
    spaceship.draw(v)
    #Bala
    bullet.x = spaceship.x
    bullet.y = spaceship.y
    bullet.border = 0
    bullet.draw(v)
    #Villanos
    #Villano 1
    villano1 = makePicture("Villano.png")
    villano1.x = 600
    villano1.y = 200
    villano1.border = 0
    villano1.draw(v)
    listaVillanos.append(villano1)
    #Villano 2
    villano2 = makePicture("Villano2.png")
    villano2.x = 600
    villano2.y = 100-5
    villano2.border = 0
    villano2.draw(v)
    listaVillanos.append(villano2)
    #Villano 3
    villano3 = makePicture("Villano3.png")
    villano3.x = 600
    villano3.y = 300
    villano3.border = 0
    villano3.draw(v)
    listaVillanos.append(villano3)
    #Puntaje
    puntajee.draw(v)
    eBalas.draw(v)
    inicioJuego.draw(v)
    instrucciones.draw(v)
    
    onKeyPress(leerTecla)
    btnStart.connect("click",atenderBoton)
    
    
    while True:
        if estado==True:
            btnStart.Visible = False
            inicioJuego.undraw()
            instrucciones.undraw()
            animarVillano(villano1)
            animarVillano2(villano2)
            animarVillano3(villano3)
            animarBalas()
            quitarVillanos(listaVillanos,listaBalas)
            puntajee.text = "Puntaje:"+str(puntaje)
            eBalas.text = "Balas:"+str(balas)
            if pierde()==True: 
                global estado
                estado == False
                gameOver()         
                
            if gana():
                global estado
                estado == False
                gameOver()
                        
        v.step(0.025)
        
    
v.run(main)