#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo A01337485
#Proyecto Final

from Graphics import *
from random import randint
from Myro import *

#La ventana del juego 
v = Window("Serpiente",800,600)
cabeza = makePicture("Torzo.png")
torzo = makePicture("Torzo.png")
punto = makePicture("Point.png")
obstaculo = makePicture("Obstacule.png")
listapuntos = []
listatorzo = []
#Start
juego = False
#Puntos
listap = [0]
count_p = 0
caca = 0
#Coordenadas puntos
xp = 0
yp = 0
move = 5
#Obstaculo
veces = [0,1]
anterior = 0
#coordenadas obstaculo
xo = 0
yo = 0
xon = 0
yon = 0

def movimiento(v,evento):
    tecla = evento.key
    direccion = 0
    coorx = cabeza.x
    coory = cabeza.y
    if tecla == "Right" and direccion != -1:
        cabeza.x += move
        torzo.x = cabeza.x -move
        torzo.y = cabeza.y
        direccion = 1
        return direccion
    elif tecla == "Left" and direccion != 1:
        cabeza.x -= move
        torzo.x = cabeza.x + move
        torzo.y = cabeza.y
        direccion = -1
        return direccion
    elif tecla == "Up" and direccion != -2:
        cabeza.y -= move
        torzo.x = cabeza.x
        torzo.y = cabeza.y + move
        direccion = 2
        """print(cabeza.x,",",cabeza.y)"""
        return direccion
    elif tecla == "Down" and direccion != 2:
        cabeza.y += move
        torzo.x = cabeza.x
        torzo.y = cabeza.y - move
        direccion = -2
        """print(cabeza.x,",",cabeza.y)"""
    return direccion
    return torzo.x
    return torzo.y
    return cabeza.x
    return cabeza.y
    
def aparicionDePuntos():
    global listap
    global xp
    global yp
    x1 = cabeza.x 
    x2 = torzo.x
    y1 = cabeza.y
    y2 = torzo.y 
    while len(listap) == 1:
        xp = randint(16,789)
        yp = randint(16,589)
        print("Punto :",xp,",",yp)
        if xp != x1 and xp != x2 and yp != y1 and yp != y2:
            punto.border = 0
            punto.x = xp
            punto.y = yp
            punto.draw(v) 
            listap.append(1)
            desaparecerPuntos()
    return listap
    return xp
    return yp
    
def siLoTocasTeMueres():
    global veces
    global xo
    global yo
    global anterior
    x1 = cabeza.x 
    x2 = torzo.x
    y1 = cabeza.y
    y2 = torzo.y
    while len(veces) > anterior:
        xo = randint(11,789)
        yo = randint(11,589)
        print (xo,",",yo)
        if xo != x1 and xo != x2 and yo != y1 and yo != y2 and yo != yp and xo != xp:
            obstaculo.border = 0
            obstaculo.x = xo
            obstaculo.y = yo
            obstaculo.draw(v) 
            veces.pop()
            anterior = len(veces)
    return veces
    return anterior
    return xo
    return yo

def desaparecerPuntos():
    global veces
    global listap
    global count_p
    p1 = xp 
    p2 = yp
    x1 = cabeza.x 
    y1 = cabeza.y
    if (p1+5) >= x1 and (p2+5) >= y1 and x1 >= (p1-5) and y1 >= (p2-5):
        beep(.3,880)
        punto.undraw()
        listap.pop()
        count_p += 50
        veces.append(1)
        aparicionDePuntos() 
    return listap
    return count_p
    return veces
    
def contadorDePuntaje():
    global count_p
    score = Text((680,20),str(count_p))
    score.xJustification = "right"
    score.fontSize = 15
    score.fill = Color ("purple")
    score.draw(v)

def desaparecesTu():
    global caca
    p1 = xo 
    p2 = yo
    x1 = cabeza.x 
    y1 = cabeza.y
    if (p1+5) >= x1 and (p2+5) >= y1 and x1 >= (p1-5) and y1 >= (p2-5) :
        cabeza.undraw()
        torzo.undraw()
        v.Visible = False
        caca += 1
        return caca
    elif x1 <= 10 or x1 >= 790 or y1 <= 10 or y1 >= 590:
        cabeza.undraw()
        torzo.undraw()
        v.Visible = False
        caca += 1
        return caca
        
def reinicio():
    archivo = open("Score.txt","w")
    jugador = str(input("Dame tu nombre jugador:"))
    archivo.write(jugador+","+str(count_p)+"\n")
    archivo.close()
        
def música(base):
    negra = base
    negraD = base/2
    blanca = base*2
    especial = negra + negraD
    beep(negra,880)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negraD,698.456)
    beep(negraD,659.255)
    beep(negra,587.33)
    beep(0.05,0)
    beep(negraD,587.33)
    beep(negraD,698.456)
    beep(negra,880)
    beep(negraD,783.991)
    beep(negraD,698.456)
    beep(negra,659.255)
    beep(0.05,0)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negra,880)
    beep(negra,698.456)
    beep(negra,587.33)
    beep(0.05,0)
    beep(blanca,587.33)
    beep(0.05,0)
    beep(negra,783.991)
    beep(negraD,932.33)
    beep(negraD,1174.659)
    beep(0.05,0)
    beep(negraD,1174.659)
    beep(negraD,1046.502)
    beep(negraD,932.33)
    beep(especial,880)
    beep(negraD,698.456)
    beep(negraD,880)
    beep(0.05,0)
    beep(negraD,880)
    beep(negraD,783.991)
    beep(negraD,698.456)
    beep(negra,659.255)
    beep(0.05,0)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negra,880)
    beep(negra,698.456)
    beep(negra,587.33)
    beep(0.05,0)
    beep(blanca,587.33)
    
   
    
def main():
    #Fondo
    fondo = makePicture("Fondo.png")
    fondo.draw(v)
    #Paredes
    Izq = Rectangle((0,0),(10,599))
    Izq.fill = Color("purple")
    Izq.draw(v)
    Der = Rectangle((789,0),(799,599))
    Der.fill = Color("purple")
    Der.draw(v)
    Arr = Rectangle((0,0),(799,10))
    Arr.fill = Color("purple")
    Arr.draw(v)
    Aba = Rectangle((0,589),(799,599))
    Aba.fill = Color("purple")
    Aba.draw(v)
    Aba.bodyType = "static"
    intro = makePicture("iNTRO.png")
    intro.x = 400
    intro.y = 300
    intro.draw(v)
    #Ini<cio
    base = 0.3
    música(base)
    v.step(0.03)
    #Cabeza
    intro.undraw()
    cabeza.border = 0 # Quita el contorno de la imagen
    cabeza.x = 400-32
    cabeza.y = 300-32
    cabeza.draw(v)
    #Torzo
    torzo.border = 0
    torzo.x = cabeza.x
    torzo.y = cabeza.y - 15
    torzo.draw(v)
    onKeyPress(movimiento)
    while juego == False:
        contadorDePuntaje()
        aparicionDePuntos()
        siLoTocasTeMueres()
        desaparecerPuntos()
        desaparecesTu()
    if caca != 1 :
        reinicio()
   
v.run(main)
