#encoding: UTF-8
#Luis Martín Barbosa Galindo A01337845
#Música Juego

#Es del juego de Tetris por Hirokazu Tanaka
from Myro import beep

def primeraEstrofa(base):
    negra = base
    negraD = base/2
    blanca = base*2
    especial = negra + negraD
    beep(negra,880)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negraD,698.456)
    beep(negraD,659.255)
    beep(negra,587.33)
    beep(0.05,0)
    beep(negraD,587.33)
    beep(negraD,698.456)
    beep(negra,880)
    beep(negraD,783.991)
    beep(negraD,698.456)
    beep(negra,659.255)
    beep(0.05,0)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negra,880)
    beep(negra,698.456)
    beep(negra,587.33)
    beep(0.05,0)
    beep(blanca,587.33)
    beep(0.05,0)
    beep(negra,783.991)
    beep(negraD,932.33)
    beep(negraD,1174.659)
    beep(0.05,0)
    beep(negraD,1174.659)
    beep(negraD,1046.502)
    beep(negraD,932.33)
    beep(especial,880)
    beep(negraD,698.456)
    beep(negraD,880)
    beep(0.05,0)
    beep(negraD,880)
    beep(negraD,783.991)
    beep(negraD,698.456)
    beep(negra,659.255)
    beep(0.05,0)
    beep(negraD,659.255)
    beep(negraD,698.456)
    beep(negra,783.991)
    beep(negra,880)
    beep(negra,698.456)
    beep(negra,587.33)
    beep(0.05,0)
    beep(blanca,587.33)
    
def main():
        base = 0.3
        primeraEstrofa(base)

main()