#encoding: utf-8
#autor: Allan Sanchez Iparrazar A01379951
#Videojuego muy básico
from Graphics import *
from random import randint
import Myro
#creamos la ventana del juego
v = Window("Juego", 800, 600)

#variables globales
patricio = makePicture("patricio.png")
medusa = makePicture("medusa.png")
seguirMedusa = makePicture("medusa.png")
cangreburguer = makePicture("cangreburguer.png")

#-------------Listas--------------#
lstCangreburguer = []
lstMedusasXP = []
lstMedusasXN = []

score = 0
lblScore = Text((100,30),"Score "+str(score))
lblScore.fill = Color("White")
lblScore.fontSize = 30
lblScore.border = 3

lblHighscore = Text((400,350),"Highscore: "+str(score))
lblHighscore.fill = Color("White")
lblHighscore.fontSize = 30
lblHighscore.border = 3

playing = False
configuracionInicial = False
regresarMenu = False
salir = False

btnInicio = Button((400-150,300),"JUGAR")
btnInicio.draw(v)
btnInicio.Visible = False

btnHighscore = Button((400-50,300),"HIGH SCORE")
btnHighscore.draw(v)
btnHighscore.Visible = False

btnMenu = Button ((300,500),"Menu")
btnMenu.draw(v)
btnMenu.Visible = False

btnSalir = Button ((400,500),"Exit")
btnSalir.draw(v)
btnSalir.Visible = False

###########VIDAS DEL JUGADOR#################
lstVida = [makePicture("vida0.png"),makePicture("vida1.png"),makePicture("vida2.png"),makePicture("vida3.png"),makePicture("vida4.png"),makePicture("vida5.png")]
vida = 5
#Variable que ayuda a que no continuen ciertos ciclos cuando pierdes
over = False
#***************************************************************************

##VELOCIDAD DE JUEGO##
#                    #
velocidadCangre = 70 #
velocidadMedusa = 70 #
#                    #
######################

#******************************************************************************

#pregunta si presionaron una tecla y ejecuta
def leerTecla(ventana,evento) :
    tecla = evento.key
    if tecla == "Right" and patricio.x < 800-50 :
        patricio.x += 20
    elif tecla == "Left" and patricio.x > 50 : 
        patricio.x -= 20
    elif tecla == "Up" and patricio.y > 60 :
        patricio.y -= 20
    elif tecla == "Down" and patricio.y < 600-60 :
        patricio.y += 20
    elif tecla == "Down" and tecla == "Right":
        patricio.x += 20
        patricio.y += 20
    elif tecla == "Down" and tecla == "Left":
        patricio.x -= 20
        patricio.y += 20
    elif tecla == "Up" and tecla == "Right":
        patricio.x += 20
        patricio.y -= 20
    elif tecla == "Up" and tecla == "Left":
        patricio.x -= 20
        patricio.y -= 20
            
#************BOTONES***************#
                            
def iniciarJuego(btn,e):
    global configuracionInicial 
    configuracionInicial = True 
    
def home (btn,e):
    global configuracionInicial, playing, regresarMenu, vida
    
    canfiguracionInicial = False
    playing = False
    regresarMenu = True
    vida = 5
    
    
   
    
def HighScores(btn,e):
    global lblHighscore
    entrada = open("highscore.txt","r")
    highscore = int(entrada.readline())
    lblHighscore = Text((400,350),"Highscore: "+str(highscore))
    lblHighscore.fill = Color("White")
    lblHighscore.fontSize = 30
    lblHighscore.border = 3
    lblHighscore.draw(v)
    entrada.close()

def exitVideoGame (btn,e):
    global salir
    salir = True
    
    
#************BOTONES***************# 


##--------------------cangreburguers--------------------------###                                        
def crearCangreburguers():
    global lstCangreburguer
    
    nuevaCangreburguer = makePicture ("cangreburguer.png")
    nuevaCangreburguer.x = randint(40,800-40)
    nuevaCangreburguer.y = -32
    nuevaCangreburguer.border = 0
    lstCangreburguer.append(nuevaCangreburguer)
    nuevaCangreburguer.draw(v)
    
def animarCangreburguers () : 
    global lstCangreburguer, score, lblScore
    if len(lstCangreburguer) >= 1 :   
        for cangreburguer in lstCangreburguer : 
            cangreburguer.y += 5
            if cangreburguer.y > 600+32 :
                #la borra
                lstCangreburguer.remove(cangreburguer)
                cangreburguer.undraw()
            
            if over == 0 :
                if abs(cangreburguer.x - patricio.x) < 20 and abs(patricio.y - cangreburguer.y) < 30 : 
                
                    lblScore.undraw()
                    score += 10
                    lstCangreburguer.remove(cangreburguer)
                    cangreburguer.undraw()
                    lblScore = Text((100,30),"Score "+str(score))
                    lblScore.fill = Color("White")
                    lblScore.fontSize = 30
                    lblScore.border = 3
                    lblScore.draw(v)
                
##---------------------cangreburgues------------------------###

###-----------------------medusas---------------------------###
def animarMedusas () : 
    global lstMedusasXP

    if len(lstMedusasXP) >= 1 :   
        for medusa in lstMedusasXP : 
            medusa.x -= 7
            if medusa.x < 0-60 :
                #la borra
                lstMedusasXP.remove(medusa)
                medusa.undraw()
            if over == False :
                if abs(medusa.x - patricio.x) < 25  and abs(patricio.y - medusa.y) < 60 : #medusa 60x80
                    vidaMenos()
                    medusa.undraw()
                    lstMedusasXP.remove(medusa)              
                                 
def crearMedusas():#falta
    global lstMedusasXP
    
    nuevaMedusa = makePicture ("medusa.png")
    nuevaMedusa.y = randint(80,600-80)
    print("**********",nuevaMedusa.y)

    nuevaMedusa.x = 800+60
    nuevaMedusa.border = 0
    lstMedusasXP.append(nuevaMedusa) 

    nuevaMedusa.draw(v)


###------------------Fin--medusas-------------------------###

                                                                                                       
def vidaMenos():
    global vida, lstVida, regresarMenu
    lstVida[vida].undraw()
    vida -= 1
    if vida == 0 :
            gameOver()
    else:
        lstVida[vida].border = 0
        lstVida[vida].x = 800-110
        lstVida[vida].y =30 
        lstVida[vida].draw(v) 

def gameOver():
    global over, lblHighscore, score, btnMenu, regresarMenu, salir, lstMedusasXP
    if over == False:
        txtGameOver = Text((400,200),"GAME OVER")
        txtGameOver.fill = Color("Black")
        txtGameOver.fontSize = 70
        txtGameOver.border = 3
        txtGameOver.draw(v)
        
        txtTuPuntaje = Text((400,275),"Tu puntaje es: "+str(score))
        txtTuPuntaje.fill = Color("White")
        txtTuPuntaje.fontSize = 50
        txtTuPuntaje.border = 3
        txtTuPuntaje.draw(v)
        
        patricio.undraw()
        
        entrada = open("highscore.txt","r")
        highscore = int(entrada.readline())
        entrada.close()
        
        if score > highscore:
            nuevoHS = open("highscore.txt","w")
            nuevoHS.write(str(score))
            nuevoHS.close()
            lblHighscore = Text((400,350),"Highscore: "+str(score))
            lblHighscore.fill = Color("Black")
            lblHighscore.fontSize = 70
            lblHighscore.border = 3
            lblHighscore.draw(v)
        else:
            lblHighscore = Text((400,350),"Highscore: "+str(highscore))
            lblHighscore.fill = Color("Black")
            lblHighscore.fontSize = 70
            lblHighscore.border = 3
            lblHighscore.draw(v)
            
        btnMenu.Visible = True
        btnSalir.Visible = True
        over = True
        while regresarMenu == False or salir == False :      
            print("estoy preguntando")
            if regresarMenu == True:
                valoresIniciales()
                main()
            
            if salir == True :
                break
                
    for medusa in len(lstMedusasXP) : 
        #la borra
        lstMedusasXP.remove(medusa)
        medusa.undraw()
    
    txtGameOver.undraw()
    txtTuPuntaje.undraw()
    lblHighscore.undraw()
    
    pass
  
def valoresIniciales():
    global playing, configuracionInicial, regresarMenu, salir, over, score, velocidadCangre,velocidadMedusa
    playing = False
    configuracionInicial = False
    regresarMenu = False
    salir = False
    over = False
    score = 0
    velocidadCangre = 70 
    velocidadMedusa = 70

def main ():
    valoresIniciales()
    global btnInicio, btnHighscore, btnSalir2, playing, configuracionInicial, lstCangreburguer, velocidad, velocidadCangre, velocidadMedusa, over, btnMenu, btnSalir
    print("estoy inicializando")
    btnMenu.Visible = False
    btnSalir.Visible = False
    
    fondoMenu = makePicture("inicioJuego.jpg")
    fondoMenu.border = 0
    fondoMenu.draw(v)
       
    btnInicio.Visible = True
    btnHighscore.Visible = True
    Myro.play("soundtrack01.wav")   
    
    txtPresentacion = Text((330,100),"PATRIC GAME")
    txtPresentacion.fill = Color("Purple")
    txtPresentacion.fontSize = 40
    txtPresentacion.draw(v)
    
    txtInstrucciones = Text((300,210),"¡Esquiva medusas y")
    txtInstrucciones.fill = Color("White")
    txtInstrucciones.fontSize = 50
    txtInstrucciones.draw(v)
        
    txtInstrucciones2 = Text((300,260),"come kangreburguers!")
    txtInstrucciones2.fill = Color("White")
    txtInstrucciones2.fontSize = 50
    txtInstrucciones2.draw(v)
    
    txtCredits = Text((150,570),"Edicion e imagen por ERIK. \nCoding and logic by All4n Xp.")
    txtCredits.fill = Color("Black")
    txtCredits.fontSize = 20
    txtCredits.border = 7
    txtCredits.draw(v)
    #fondo
    fondo = makePicture("fondo2.png")
    
    #patricio    
    patricio.border = 0 #quita el marco
    patricio.x = 400
    patricio.y = 300
    
    #eventos del teclado
    onKeyPress(leerTecla)
    
    #eventos del mouse
    btnInicio.connect("click",iniciarJuego)
    btnHighscore.connect("click",HighScores)
    btnSalir.connect("click",exitVideoGame)
    btnMenu.connect("click",home)
    
    #iniciamos los contadores
    contBurguers = 0
    contMedusas = 0
    
    #velocidad con las que cae la cangreburguers
    #velBurguers = 0 

    #retardo del juego para ir aumentando la dificultad
    retardoCangreburguers = 0               
    retardoMedusas = 0 
    
    over = False 
    print("Ya acabe de iniciar")
    #ciclo del juego
    while True:
        
        v.step(0.025) #retardo
        if configuracionInicial == True :
            configuracionInicial = False
            fondo.draw(v)
            fondoMenu.undraw()
            btnInicio.Visible = False
            btnHighscore.Visible = False
            btnSalir2 = False
            txtPresentacion.undraw()
            print("PatricioDebería imprimirse")
            patricio.draw(v)
            lstVida[vida].border = 0
            lstVida[vida].x = 800-110
            lstVida[vida].y =30
            lstVida[vida].draw(v)
            lblScore.draw(v)
            #Manda la instruccion para que empiece el juego 
            playing = True
            
        if playing == True:

            if over == False :
                #un pequeño ciclo para que no salgan tantas cangreburguers
                if contBurguers > velocidadCangre :
                    crearCangreburguers()
                    contBurguers = 0
                    print("velocidad actual de cangre",velocidadCangre)
                
                    if (retardoCangreburguers > 10) and (velocidadCangre > 11) :
                        velocidadCangre -=10
                        print("Cambia la velocidad de cangre a",velocidadCangre)
                        retardoCangreburguers = 0
                
                    retardoCangreburguers += 1
                contBurguers += 1
            
                #pequeño ciclo que crea cierta cantidad de medusas medusas
                if contMedusas > velocidadMedusa :
                    crearMedusas()
                    contMedusas = 0
                    print("Velocidad actual de MEDUSA",velocidadMedusa)
                
                    if (retardoMedusas > 10) and (velocidadMedusa > 16) :
                        velocidadMedusa -=10
                        print("Cambia la velocidad de MEDUSA a ",velocidadMedusa)
                        retardoMedusas = 0
                
                    retardoMedusas += 1
                contMedusas += 1
            
                animarCangreburguers()
                animarMedusas()
                
v.run(main)#corre un ciclo de juego y como parte de este ejecuta main