#encoding: UTF-8
#Marlon Brandon Velasco Pinello, A01379404
#Proyecto Final juego: Tamagotchi
from Graphics import *
from random import randint
from Myro import *
from time import time
tiempo = time()
v = Window("Tamagotchi",400,400)
fondo=makePicture("fondo.jpg")
fondo.border=0
fondo.draw(v)
iHamber=makePicture("hmbr.png")
iSueño=makePicture("zzzz.png")
iSalud=makePicture("crzn.png")
logo=makePicture("tamagochi.png")
iFelicidad=makePicture("flz.png")
btnHambre = Button((30,350),"Comer")
btnSueño = Button((130,350),"Dormir")
btnCurar = Button((230,350),"Curar")
btnJugar = Button((330,350),"Jugar")
btnInicio = Button((180,250),"Inicio")
btnReglas = Button((180,285),"Reglas")
btnSalir = Button((180,325),"Salir")
btnInicio.draw(v)
btnReglas.draw(v)
btnSalir.draw(v)

hambre=100
salud=100
felicidad=100
sueño=100
iH = Text((0,0),"")
iD = Text((0,0),"")
iF = Text((0,0),"")
iS = Text((0,0),"")




def generarTamas():
    dos=randint(21,22)
    tres=randint(31,32)
    cuatro=randint(41,43)
    evolucion={"evol1":1,"evol2":dos,"evol3":tres,"evol4":cuatro}
    return evolucion

def quitarIndicadores():
    iSueño.undraw()
    iHamber.undraw()
    iSalud.undraw()
    iFelicidad.undraw()

def dibujarIndicadores():
    iSueño.border=0
    iSueño.x=160
    iSueño.y=45
    iSueño.draw(v)
    btnSueño.draw(v)
    dibujarLD()
    #iHamber=makePicture("hmbr.png")
    iHamber.border=0
    iHamber.x=60
    iHamber.y=45
    iHamber.draw(v)
    btnHambre.draw(v)
    dibujarLH()
    #iSalud=makePicture("crzn.png")
    iSalud.border=0
    iSalud.x=250
    iSalud.y=45
    iSalud.draw(v)
    btnCurar.draw(v)
    dibujarLS()
    #iFelicidad=makePicture("flz.png")
    iFelicidad.border=0
    iFelicidad.x=340
    iFelicidad.y=45
    iFelicidad.draw(v)
    btnJugar.draw(v)
    dibujarLF()
    aparecerBtn()
    
def aparecerBtn():
    btnJugar.Visible= True
    btnCurar.Visible= True
    btnHambre.Visible= True
    btnSueño.Visible= True
    
def desaparecerBtn():
    btnJugar.Visible= False
    btnCurar.Visible= False
    btnHambre.Visible= False
    btnSueño.Visible= False
    
def dibujarTama(evolucion,evol):
    if evol == 0:
        personaje=makePicture("tama"+str(evolucion["evol1"])+".png")
    elif evol==1:
        personaje=makePicture("tama"+str(evolucion["evol2"])+".png")
    elif evol==2:
        personaje=makePicture("tama"+str(evolucion["evol3"])+".png")
    elif evol==3:
        personaje=makePicture("tama"+str(evolucion["evol4"])+".png")
    personaje.border=0
    personaje.x=200
    personaje.y=300
    personaje.draw(v)
    return personaje

def dibujarLH():
    global iH
    if hambre>100:
        iH = Text((345,90),"100%")
    elif hambre<100:
        iH = Text((345,90),"0%")
    else:
        iH = Text((65,90),str(hambre)+"%")
    iH.fontSize = 25
    iH.draw(v)
    
def dibujarLD():
    global iD
    if sueño>100:
        iD = Text((345,90),"100%")
    elif sueño<100:
        iD = Text((345,90),"0%")
    else:
        iD = Text((160,90),str(sueño)+"%")
    iD.fontSize = 25
    iD.draw(v)
    
def dibujarLF():
    global iF
    if felicidad>100:
        iF = Text((345,90),"100%")
    elif felicidad<100:
        iF = Text((345,90),"0%")
    else:
        iF = Text((345,90),str(felicidad)+"%")
    iF.fontSize = 25
    iF.draw(v)

def dibujarLS():
    global iS
    if salud>100:
        iS = Text((345,90),"100%")
    elif salud<100:
        iS = Text((345,90),"0%")
    else:
        iS = Text((260,90),str(salud)+"%")
    iS.fontSize = 25
    iS.draw(v)
    
def alimentar():
    global hambre
    global iH
    iH.undraw()
    if hambre<=100 and hambre>85:
        hambre=100
    elif hambre<=85:
        hambre+=15
    dibujarLH()
    
def despertar():
    global sueño
    global iD
    iD.undraw()
    if sueño<=100 and sueño>85:
        sueño=100
    elif sueño<=85:
        sueño+=15
    dibujarLD()
    
def curar():
    global salud
    global iS
    iS.undraw()
    if hambre>70 and sueño>70 and felicidad>70:
        if salud<=100 and salud>85:
            salud=100
        elif salud<=85 and salud>0:
            salud+=15
    dibujarLS()

def juegoPiedra():
    computadora=randint(1,3)
    jugada=int(input("1.Piedra\n2.Papel\n3.Tijera\nOpcion:"))
    if (jugada >= 1 and jugada <= 3):
        #segundo filtro, si las jugadas son iguales, hay un empate
        if(jugada == computadora):
            ganador="Empate, eligieron lo mismo"
        #a partir de aqui se evaluan los posibles casos
        if(jugada == 1 and computadora == 2):
            ganador="Pierde, el papel cubre la piedra"
        elif(jugada == 1 and computadora == 3):
            ganador="Gana, la piedra rompe las tijeras"
        if(jugada == 2 and computadora == 1):
            ganador="Gana, el papel cubre la piedra"
        elif(jugada == 2 and computadora == 3):
            ganador="Pierde, las tijeras cortan el papel"
        if(jugada == 3 and computadora == 1):
            ganador="Pierde, la piedra rompe las tijeras"
        elif(jugada == 3 and computadora == 2):
            ganador="Gana, las tijeras rompen el papel"
    #en caso que el primer filtro no sea valido, se declara una jugada invalida
    else:
        ganador="Jugada invalida"
    input(ganador)
    return ganador

def jugar():
    global felicidad
    global iF
    desaparecerBtn()
    result=juegoPiedra()
    aparecerBtn()
    if result=="Gana":
        iF.undraw()
        if felicidad<=100 and felicidad>85:
            felicidad=100
        elif felicidad<=85:
            felicidad+=15
        dibujarLF()
    
    

def atenderBoton(boton, evento):
    if boton == btnHambre:
        alimentar()
    if boton == btnSueño:
        despertar()
    if boton == btnCurar:
        curar()
    if boton == btnJugar:
        jugar()
    if boton == btnInicio:
        desaparecerInicio()
        juego()
        main()
    if boton == btnReglas:
        desaparecerInicio()
        reglas()
        main()
    if boton == btnSalir:
        v.close()

def reglas():
    entrada = open("reglas.txt","r")
    contenido=entrada.read()
    reg = Text((200,200),"Reglas\n"+str(contenido))
    reg.fontSize = 15
    reg.draw(v)
    entrada.close()
    input("Listo?")
    reg.undraw()
    
    
def juego():
    global salud
    global hambre
    global felicidad
    global sueño
    evolucion=generarTamas()
    evol=0
    personaje=dibujarTama(evolucion,evol)
    dibujarIndicadores()
    aparecerBtn()
    btnHambre.connect("click", atenderBoton)
    btnSueño.connect("click", atenderBoton)
    btnCurar.connect("click", atenderBoton)
    btnJugar.connect("click", atenderBoton)
    setVoice("es")
    tiempo=time()
    accion=0
    #print(evolucion)
    #quitarIndicadores()
    while True:
        tiempoF = time() 
        tiempoE = tiempoF - tiempo
        #print(tiempoE)
        if salud>0:
            if tiempoE>120 and tiempoE<125:
                if tiempoE>0 and tiempoE<16:
                    if accion==0:
                        hambre-=30
                        sueño-=25
                        iH.undraw()
                        iD.undraw()
                        dibujarLH()
                        dibujarLD()
                
                elif tiempoE>20 and tiempoE<25:
                    if accion==1:
                        salud-=30
                        felicidad-=40
                        iS.undraw()
                        iF.undraw()
                        dibujarLS()
                        dibujarLF()
                        
                elif tiempoE>40 and tiempoE<45:
                    if accion==2:
                        hambre-=20
                        sueño-=10
                        felicidad-=5
                        iH.undraw()
                        iF.undraw()
                        iD.undraw()
                        dibujarLH()
                        dibujarLF()
                        dibujarLD()
                        
                elif tiempoE>100 and tiempoE<105:
                    if accion==3:
                        salud-=30
                        hambre-=50
                        sueño-=20
                        felicidad+=10
                        iD.undraw()
                        iS.undraw()
                        iF.undraw()
                        iH.undraw()
                        dibujarLS()
                        dibujarLF()
                        dibujarLD()
                        dibujarLH()
                        accion=0
                
                if evol==0:
                    #print(tiempoE)
                    #print(evolucion)
                    #print(evol)
                    evol+=1
                    speak("Evolucion"+str(evol))
                    personaje.undraw()
                    personaje=dibujarTama(evolucion,evol)
                    tiempo= time()
                elif evol==1:
                    #print(tiempoE)
                    #print(evolucion)
                    #print(evol)
                    evol+=1
                    speak("Evolucion"+str(evol))
                    personaje.undraw()
                    personaje=dibujarTama(evolucion,evol)
                    tiempo= time()
                elif evol==2:
                    #print(tiempoE)
                    #print(evolucion)
                    #print(evol)
                    evol+=1
                    speak("Evolucion"+str(evol))
                    personaje.undraw()
                    personaje=dibujarTama(evolucion,evol)
                    tiempo= time()
                elif evol==3:
                    input("Ganaste")
                    speak("Ganaste Campeon")
                    #print(evol)
                    break
        else:
            input("Perdiste")
            speak("Murio, Tamagotchi")
            #print(evol)
            break
    input("Menu")
    
    #vi=Window("Taa",800,600)
    
def aparecerInicio():
    logo.border=0
    logo.x=200
    logo.y=150
    logo.draw(v)
    btnInicio.Visible=True
    btnSalir.Visible=True
    btnReglas.Visible=True

def desaparecerInicio():
    btnInicio.Visible=False
    btnSalir.Visible=False
    btnReglas.Visible=False
    logo.undraw()

def main():
    quitarIndicadores()
    desaparecerBtn()
    aparecerInicio()
    btnInicio.connect("click", atenderBoton)
    btnReglas.connect("click", atenderBoton)
    btnSalir.connect("click", atenderBoton)
    
main()
        
            
            #print(tiempoI)
    


