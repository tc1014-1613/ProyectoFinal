#encoding: UTF-8
#Marlon Brandon Velasco pinello, A01379404
#Proyecto Juego: Tamagotchi
from Graphics import *
from random import randint
from Myro import *
from time import time

#Variable para que todos sirva bien
opc=False

#ventanas
vJuego=Window("Tamagotchi",400,400)
vMenu=Window("Menu",400,400)
vReglas=Window("Reglas",400,400)
#Ventanas invisibles
vJuego.Visible=False
vReglas.Visible=False
#botones vJuego
btnHambre = Button((30,350),"Comer")
btnDormir = Button((130,350),"Dormir")
btnCurar = Button((230,350),"Curar")
#jugar
btnJuegar = Button((330,350),"Jugar")
#botones Menu
btnInicio = Button((180,250),"Inicio")
btnReglas = Button((180,285),"Reglas")
btnSalir = Button((180,325),"Salir")
#botones Regreso al Menu
btnOk=Button((180,285),"Ok")
#Indicadores del Tamagotchi
hambre=100
salud=100
felicidad=100
dormir=100
#Textos de los indicadores
iH = Text((65,90),str(hambre)+"%")
iD = Text((160,90),str(dormir)+"%")
iS = Text((260,90),str(salud)+"%")
iF = Text((345,90),str(felicidad)+"%")
#Texto Reglas
reg = Text((200,200),"")

#funcion para generar tamagootchis
def generarTamas():
    dos=randint(21,22)
    tres=randint(31,32)
    cuatro=randint(41,43)
    evolucion={"evol1":1,"evol2":dos,"evol3":tres,"evol4":cuatro}
    return evolucion

#funcion para actualizar Labels de Indicadores
def actualizarI():
    iH.text=str(hambre)+"%"
    iD.text=str(dormir)+"%"
    iS.text=str(salud)+"%"
    iF.text=str(felicidad)+"%"
    
#funcion Juego Piedra Papel Tijera
def juegoPiedra():
    computadora=randint(1,3)
    jugada=int(input("1.Piedra\n2.Papel\n3.Tijera\nOpcion:"))
    if (jugada >= 1 and jugada <= 3):
        #segundo filtro, si las jugadas son iguales, hay un empate
        if(jugada == computadora):
            ganador="Empate, eligieron lo mismo"
        #a partir de aqui se evaluan los posibles casos
        if(jugada == 1 and computadora == 2):
            ganador="Pierde, el papel cubre la piedra"
        elif(jugada == 1 and computadora == 3):
            ganador="Gana, la piedra rompe las tijeras"
        if(jugada == 2 and computadora == 1):
            ganador="Gana, el papel cubre la piedra"
        elif(jugada == 2 and computadora == 3):
            ganador="Pierde, las tijeras cortan el papel"
        if(jugada == 3 and computadora == 1):
            ganador="Pierde, la piedra rompe las tijeras"
        elif(jugada == 3 and computadora == 2):
            ganador="Gana, las tijeras rompen el papel"
    #en caso que el primer filtro no sea valido, se declara una jugada invalida
    else:
        ganador="Jugada invalida"
    input(ganador)
    return ganador

#funcion para alimentar
def alimentar():
    global hambre
    if hambre<=100 and hambre>85:
        hambre=100
    elif hambre<=85:
        hambre+=15
    actualizarI()
#funcion para despertar
def despertar():
    global dormir
    if dormir<=100 and dormir>85:
        dormir=100
    elif dormir<=85:
        dormir+=15
    actualizarI()
#funcion para curar
def curar():
    global salud
    if salud<=100 and salud>85:
        salud=100
    elif salud<=85:
        salud+=15
    actualizarI()
#funcion para jugar
def jugar():
    global felicidad
    result=juegoPiedra()
    if result=="Gana":
        if felicidad<=100 and felicidad>85:
            felicidad=100
        elif felicidad<=85:
            felicidad+=15
        actualizarI()

#funcion para atender botones
def atenderBoton(boton, evento):
    if boton == btnHambre:
        alimentar()
    elif boton == btnDormir:
        despertar()
    elif boton == btnCurar:
        curar()
    elif boton == btnJuegar:
        jugar()
    elif boton == btnInicio:
        global opc
        opc=True
        vMenu.Visible=False
        vJuego.Visible=True
        
    elif boton == btnReglas:
        vMenu.Visible=False
        vReglas.Visible=True
    elif boton == btnSalir:
        vMenu.close()
        vJuego.close()
        vReglas.close()
    elif boton == btnOk:
        vReglas.Visible=False
        vMenu.Visible=True
        
#funcion para ir al Menu al final del juego
def finalJuego():
    global salud
    global dormir
    global hambre
    global felicidad
    salud=100
    dormir=100
    hambre=100
    felicidad=100
    vJuego.Visible=False
    vMenu.Visible=True
    
#Funcion para generar Tamagotchis
def dibujarTama(evolucion,evol):
    if evol == 0:
        personaje=makePicture("tama"+str(evolucion["evol1"])+".png")
    elif evol==1:
        personaje=makePicture("tama"+str(evolucion["evol2"])+".png")
    elif evol==2:
        personaje=makePicture("tama"+str(evolucion["evol3"])+".png")
    elif evol==3:
        personaje=makePicture("tama"+str(evolucion["evol4"])+".png")
    personaje.border=0
    personaje.x=200
    personaje.y=300
    personaje.draw(vJuego)
    return personaje
    
#funcion principal main
def main():
    fondoVJ=makePicture("fondo.jpg")
    fondoVM=makePicture("fondo.jpg")
    fondoVR=makePicture("fondo.jpg")
    '''
    saludVJ=makePicture("crzn.png")
    saludVJ.border=0
    saludVJ.x=250
    saludVJ.y=45
    saludVJ.draw(vJuego)'''
    
    tituloVM=makePicture("tamagochi.png")
    tituloVM.border=0
    tituloVM.x=250
    tituloVM.y=200
    tituloVM.draw(vMenu)
    
    entrada = open("reglas.txt","r")
    contenido=entrada.read()
    reg.text="Reglas\n"+str(contenido)
    entrada.close()
    
    
    
    
    iH.fontSize = 25
    iD.fontSize = 25
    iS.fontSize = 25
    iF.fontSize = 25
    reg.fontSize = 15
    fondoVJ.draw(vJuego)
    fondoVM.draw(vMenu)
    fondoVR.draw(vReglas)
    btnHambre.draw(vJuego)
    btnDormir.draw(vJuego)
    btnCurar.draw(vJuego)
    btnJuegar.draw(vJuego)
    btnInicio.draw(vMenu)
    btnReglas.draw(vMenu)
    btnSalir.draw(vMenu)
    btnOk.draw(vReglas)
    fondoVJ.draw(vJuego)
    fondoVM.draw(vMenu)
    fondoVR.draw(vReglas)
    iH.draw(vJuego)
    iD.draw(vJuego)
    iF.draw(vJuego)
    iS.draw(vJuego)
    reg.draw(vReglas)
    ###
    evolucion=generarTamas()
    global salud
    global hambre
    global dormir
    global felicidad
    ###
    btnHambre.connect("click", atenderBoton)
    btnDormir.connect("click", atenderBoton)
    btnCurar.connect("click", atenderBoton)
    btnJuegar.connect("click", atenderBoton)
    btnInicio.connect("click", atenderBoton)
    btnReglas.connect("click", atenderBoton)
    btnSalir.connect("click", atenderBoton)
    btnOk.connect("click", atenderBoton)
    
    ###
    setVoice("es")
    
    accion=0
    evol=0
    personaje=dibujarTama(evolucion,evol)
    personaje.draw(vJuego)
    ###
    global opc
    if True:
        hambreVJ=makePicture("hmbr.png")
        hambreVJ.border=0
        hambreVJ.x=60
        hambreVJ.y=45
        hambreVJ.draw(vJuego)
    
        dormirVJ=makePicture("zzzz.png")
        dormirVJ.border=0
        dormirVJ.x=160
        dormirVJ.y=45
        dormirVJ.draw(vJuego)
    
        felicidadVJ=makePicture("flz.png")
        felicidadVJ.border=0
        felicidadVJ.x=250
        felicidadVJ.y=45
        felicidadVJ.draw(vJuego)
    
        saludVJ=makePicture("crzn.png")
        saludVJ.border=0
        saludVJ.x=340
        saludVJ.y=45
        saludVJ.draw(vJuego)
        print(opc)
        tiempo=time()
        while True:
            tiempoF = time() 
            tiempoE = tiempoF - tiempo
            ###
            if salud>0:
                if tiempoE>120 and tiempoE<125:
                    if tiempoE>2 and tiempoE<25:
                        if accion==0:
                            hambre-=30
                            dormir-=25
                            
                    
                    elif tiempoE>40 and tiempoE<45:
                        if accion==1:
                            salud-=30
                            felicidad-=40
                            
                        
                    elif tiempoE>65 and tiempoE<70:
                        if accion==2:
                            hambre-=20
                            dormir-=10
                            felicidad-=5
                        
                        
                    elif tiempoE>110 and tiempoE<115:
                        if accion==3:
                            salud-=30
                            hambre-=50
                            dormir-=20
                            felicidad+=10
                            accion=0
                
                    if evol==0:
                        #print(tiempoE)
                        #print(evolucion)
                        #print(evol)
                        evol+=1
                        speak("Evolucion"+str(evol))
                        personaje.undraw()
                        personaje=dibujarTama(evolucion,evol)
                        tiempo= time()
                    elif evol==1:
                        #print(tiempoE)
                        #print(evolucion)
                        #print(evol)
                        evol+=1
                        speak("Evolucion"+str(evol))
                        personaje.undraw()
                        personaje=dibujarTama(evolucion,evol)
                        tiempo= time()
                    elif evol==2:
                        #print(tiempoE)
                        #print(evolucion)
                        #print(evol)
                        evol+=1
                        speak("Evolucion"+str(evol))
                        personaje.undraw()
                        personaje=dibujarTama(evolucion,evol)
                        tiempo= time()
                    elif evol==3:
                        evol=0
                        accion=0
                        speak("Ganaste Campeon")
                        input("Ganaste")
                        #print(evol)
                        break
                        finalJuego()
            else:
                evol=0
                accion=0
                speak("Murio, Tamagotchi")
                input("Perdiste")
                #print(evol)
                if hambre<0:
                    hambre=0
                elif hambre>100:
                    hambre=100
                if dormir<0:
                    dormir=0
                elif dormir>100:
                    dormir=100
                if felicidad<0:
                    felicidad=0
                elif felicidad>100:
                    felicidad=100
                if salud<0:
                    salud=0
                elif salud>100:
                    salud=100
                actualizarI()
                break
                finalJuego()
            if hambre<0:
                hambre=0
            elif hambre>100:
                hambre=100
            if dormir<0:
                dormir=0
            elif dormir>100:
                dormir=100
            if felicidad<0:
                felicidad=0
            elif felicidad>100:
                felicidad=100
            if salud<0:
                salud=0
            elif salud>100:
                salud=100
            actualizarI()
        
vJuego.run(main)
            
            
            ###
        
        
        
        
    
    
    
    