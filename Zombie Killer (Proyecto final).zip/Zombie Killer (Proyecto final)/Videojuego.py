#encoding:UTF-8
#Autor: Marina Itzel Haro Hernández, A01373471
#Videojuego proyecto final

from Graphics import*
from Myro import play
from random import randint


v = Window ("Zombie Killer", 800, 600)
zombie = makePicture("zombie.png")
shooter = makePicture("shooter.png")
nurse = makePicture("nurse.png")
bala = makePicture("bala.png")
listaBalas = []
listaZombies = []
listaZombies1 = []
acumPuntos = Text( (100,50), "Puntos : 0")
acumPuntos.color = Color("white")
puntos = 0
juego = True
  
def reiniciarJuego(btn,n):
    v.close()
    v.run(main)
    
def salirJuego(btn,n):
    v.close()
 
def leerTecla(ventana, evento):
    tecla = evento.key
    if tecla == 'Up':
        shooter.y -= 20
        bala.y -= 20
    elif tecla == 'Down':
        shooter.y += 20
        bala.y += 20
    elif tecla == 'space':
        nuevaBala = makePicture("bala.png")
        play("disparo.wav")
        nuevaBala.x = bala.x
        nuevaBala.y = bala.y
        nuevaBala.border = 0
        nuevaBala.draw(v)
        listaBalas.append(nuevaBala)
        
def animarBalas():
    
    for nuevaBala in listaBalas:
        nuevaBala.x += 30
        if nuevaBala.x < 0:
            listaBalas.remove(nuevaBala)
            nuevaBala.undraw()
        
        
def animarZombies(): 
    zombie = makePicture("zombie.png")
    zombie.x = randint(600, 800)
    zombie.y = randint(30, 600-30)
    zombie.border = 0
    listaZombies.append(zombie)
    if len(listaZombies)<=16:
        zombie.draw(v)
    else:
        listaZombies.remove(zombie)
    for zombie in listaZombies: 
        zombie.x -= 3
        

def matarZombies():
    global puntos
    for nuevaBala in listaBalas:
        for zombie in listaZombies:
            ancho = zombie.width
            largo = zombie.height
            if nuevaBala.x >= zombie.x-(ancho/3) and nuevaBala.x <= zombie.x+(ancho/3): 
                if nuevaBala.y >= zombie.y-(largo/3) and nuevaBala.y <= zombie.y+(largo/3):
                    listaZombies.remove(zombie)
                    zombie.undraw()
                    play("zombie.wav") 
                    puntos += 1
                    acumPuntos.text = "Puntos: " + str(puntos)
                
def matarShooter():
    global juego
    for zombie in listaZombies:
        if shooter.x == zombie.x:
            txtPierde = Text( (400, 300), "Game over" )
            txtPierde.fontSize = 40
            txtPierde.color = Color("White")
            txtPierde.draw(v)
            btnSalir = Button((390, 400), "Salir" )
            btnSalir.draw(v)
            btnSalir.connect("click", salirJuego)
            btnReset = Button((365, 350), "Nuevo Juego" )
            btnReset.draw(v)
            btnReset.connect("click", reiniciarJuego)
            juego = False
 
def main():
    #play("zombiekiller.wav")
    fondo = makePicture("fondo.png")
    fondo.draw(v)
    
    shooter.border = 0 
    shooter.x = 60 
    shooter.y = 300-30
    shooter.draw(v)
    
    bala.x = 120
    bala.y = 300+5
    bala.border = 0
   
    onKeyPress(leerTecla)
    
    while True:
        v.step(0.025)
        if juego == True: 
            acumPuntos.draw(v)
            animarBalas()
            animarZombies()
            matarZombies()
            matarShooter()
     
 
                                                      
    
v.run(main)
