
from Graphics import *
from random import randint
from Myro import beep

v = Window("Juego", 800, 450)
v.mode = "physics"
v.gravity = Vector (0,9)
incDementor = 3
pb = makePicture("spell.png")
listaH = []
listaH1 = []
c = 0


def menu():
    global texto,text,titulo, fondo, punt, puntaje
    fondo = makePicture("castillo.jpg")
    fondo.bodyType = "static"
    fondo.draw(v)
    titulo = Text((400,100),"Harry Potter: The Game")
    texto = Text((400,150), "Mata dementores, no te salgas de la pantalla, DIVIERTETE")
    text = Text ((400,175),"Presiona espacio para comenzar")
    punt = Text ((400,400), "Tu puntaje anterior fue de:")
    puntaje = Text((400,415), str(c))
    texto.fontSize = 20
    titulo.fontSize = 44
    text.fontSize = 15
    punt.fontSize = 20
    puntaje.fontSize = 20
    texto.color = Color("White")
    text.color = Color("White")
    titulo.color = Color("White")
    punt.color = Color("White")
    puntaje.color = Color("Red")
    texto.bodyType = "static"
    titulo.bodyType = "static"
    text.bodyType = "static"
    punt.bodyType = "static"
    puntaje.bodyType = "static"
    texto.draw(v)
    titulo.draw(v)
    text.draw(v)
    puntaje.draw(v)
    punt.draw(v)
    onKeyPress(leerTecla)
    
def animarDementor(dementor, coor):
    global incDementor
    if coor == 1:
        dementor.x += incDementor
        if dementor.x >800-15 or dementor.x<482:
            incDementor *= -1
    elif coor == 2:
        dementor.x += incDementor
        if dementor.x >600 or dementor.x<200:
            incDementor *= -1
    elif coor == 3:
        dementor.x += incDementor
        if dementor.x >376 or dementor.x<24:
            incDementor *= -1
    elif coor == 4:
        dementor.x += incDementor
        if dementor.x >700 or dementor.x<114:
            incDementor *= -1
    elif coor == 5:
        dementor.x += incDementor
        if dementor.x >136 or dementor.x<10:
            incDementor *= -1
    elif coor == 6:
        dementor.x += incDementor
        if dementor.x <650 or dementor.x>800:
            incDementor *= -1
            
        
    
    
    

def crearPlataformas():
    global p1,p2,p3,p4,p5,p6,p7
    p1 = Rectangle ( (450,425), (800,450))
    p1.bodyType = "static"
    p1.color = Color("gray")
    p1.draw(v)
    p2 = Rectangle ( (0,425), (350,450))
    p2.color = Color("gray")
    p2.bodyType = "static"
    p2.draw(v)
    p3 = Rectangle ( (100,325), (700,350))
    p3.color = Color("gray")
    p3.bodyType = "static"
    p3.draw(v)
    p4 = Rectangle ( (200,225), (600,250))
    p4.color = Color("gray")
    p4.bodyType = "static"
    p4.draw(v)
    p5 = Rectangle ( (0,125), (150,150))
    p5.color = Color("gray")
    p5.bodyType = "static"
    p5.draw(v)
    p6 = Rectangle ( (650,125), (800,150))
    p6.color = Color("gray")
    p6.bodyType = "static"
    p6.draw(v)
    p7 = Rectangle ( (300,90), (500,115))
    p7.color = Color("gray")
    p7.bodyType = "static"
    p7.draw(v)
    
def crearPersonaje():
    global harry
    harry = Picture("potter1.png")
    harry.x = 60
    harry.y = 50
    harry.draw(v)
    harry.mass = -1000
    harry.border = 0
    harry.friction = 0.20
    harry.bounce = 0

def crearDementor(lugar):
    global dementor
    global coor
    incPikachu = 3
    dementor = Picture("dementor1.png")
    dementor.bodyType = "static"
    dementor.border = 0
    if lugar == 1:
        coor = 1
        dementor.x = 700
        dementor.y = 400
        dementor.draw(v)
        animarDementor(dementor, coor)
    elif lugar == 2:
        coor = 2
        dementor.x = 200
        dementor.y = 200
        dementor.draw(v)
        animarDementor(dementor, 2)
    elif lugar == 3:
        coor = 3
        dementor.x = 25
        dementor.y = 400
        dementor.draw(v)
        animarDementor(dementor, 3)
    elif lugar == 4:
        coor = 4
        dementor.x = 125
        dementor.y = 300
        dementor.draw(v)
        animarDementor(dementor, 4)
    elif lugar == 5:
        coor = 5
        dementor.x = 15
        dementor.y = 100
        dementor.draw(v)
        animarDementor(dementor, 5)
    if lugar == 6:
        coor = 6
        dementor.x = 675
        dementor.y = 100
        dementor.draw(v)
        animarDementor(dementor, 6)        
          
def leerTecla(ventana, evento):
    tecla = evento.key
    if tecla == "Right":
        harry.x += 20
        pb.moveTo(harry.x,harry.y)
    elif tecla == "Left":
        harry.x -= 20
        pb.moveTo(harry.x,harry.y)
    elif tecla == "Up":
        harry.y -= 40
        pb.moveTo(harry.x,harry.y)
        zc = pb
    elif tecla == "Down":
        harry.y += 10
        pb.moveTo(harry.x,harry.y)
    elif tecla == "d":
        nuevaPb = makePicture ("spell.png")
        nuevaPb.border = 0
        nuevaPb.x =pb.x
        nuevaPb.y =pb.y
        nuevaPb.draw(v)
        nuevaPb.bodyType = "static"
        listaH.append(nuevaPb)
    elif tecla == "a":
        nuevaPb1 = makePicture ("spell.png")
        nuevaPb1.border = 0
        nuevaPb1.x =(pb.x-30)
        nuevaPb1.y =pb.y
        nuevaPb1.draw(v)
        nuevaPb1.bodyType = "static"
        listaH1.append(nuevaPb1)
    elif tecla == "space":
        texto.undraw()
        text.undraw()
        titulo.undraw()
        fondo.undraw()
        punt.undraw()
        puntaje.undraw()
        main()
        
def animarPokebolas():            
    for pb in listaH:
        pb.x +=5
        if pb.x > 816:
            listaH.remove(pb)
            pb.undraw()
    for pb in listaH1:
        pb.x -=5
        if pb.x < -16:
            listaH1.remove(pb)
            pb.undraw()

def main():
    global c
    c = 0
    crearPlataformas()
    crearPersonaje()
    crearDementor(randint(1,6))
    jugar = True
    onKeyPress(leerTecla)
    while jugar == True:
        animarDementor(dementor, coor)
        animarPokebolas()
        for pb in listaH:
            if pb.y > (dementor.y-25) and pb.x > (dementor.x-15) and pb.y < (dementor.y+25) and pb.x < (dementor.x+15):
                dementor.undraw()
                pb.undraw()
                beep(1, 300)
                c += 1
                print("Puntaje:",c)
                crearDementor(randint(1,6))
                
        for pb in listaH1:
            if pb.y > (dementor.y-25) and pb.x > (dementor.x-15) and pb.y < (dementor.y+25) and pb.x < (dementor.x+15):
                dementor.undraw()
                pb.undraw()
                beep(1, 300)
                c += 1
                print("Puntaje:",c)
                crearDementor(randint(1,6))
                
        if (harry.y >= 450) or (harry.x < 0) or (harry.x > 800):
            harry.undraw()
            dementor.undraw()
            p1.undraw()
            p2.undraw()
            p3.undraw()
            p4.undraw()
            p5.undraw()
            p6.undraw()
            p7.undraw()
            jugar = False
            menu()
            return jugar
        v.step(0.020)


v.run(menu)