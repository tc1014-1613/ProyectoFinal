#encoding:UTF-8
#Lenin Silva Gtz, A01373214
#Código Snakes

from random import randrange
from Graphics import *

#Ventana
s = Window("Snake",800,400)
s.setBackground(Color("black"))
border = Rectangle((15,15),(785,385))
border.fill = Color("white")
border.draw(s)

#Snake
head = makePicture("Images\\pixel.png")
head.x = 400
head.y = 200
head.border = 0
headPosX = []
headPosY = []
bodyList = []

#Cuadros
cuadro = makePicture("Images\\pixel.png")
cuadro.border = 0
hayCuadro = False
        
#Movimiento
desplazamiento = 10
direccion = "Right"

#Botones y variables de incio/final
startGame = Button((380,200),"START")
startS = False
newGameS = Button((370,200),"NEW GAME")
end = Button((370,250),"END GAME")

#Puntaje
scoreS = 0
puntS = [Text((10,10),"")]
snakeHigh = ""
resHS = Button((365,250), "RESET TOP5")
high = []

juegoS = True

def darInicio():
    puntajeMaxS()
    startGame.draw(s)
    resHS.draw(s)
    startGame.connect("click", empezarJuego)
    resHS.connect("clicl",resetTopS)       
        
def empezarJuego(btn,e):
    global startS, headPosX, headPosY, bodyList,high
    for i in high:
        i.undraw()
    btn.Visible = False
    resHS.Visible = False
    high[-1].undraw()
    head.draw(s)
    startS = True
    
def moverSnake(v,e):
    global direccion
    direccion = e.key
    
def animarSnake():        
    if direccion == "Up":
        head.y -= desplazamiento
    elif direccion == "Down":
        head.y += desplazamiento
    elif direccion == "Right":
        head.x += desplazamiento
    elif direccion == "Left":
        head.x -= desplazamiento
    
    headPosX.insert(0,head.x)
    headPosY.insert(0,head.y)
    
    contador = 1
    for bod in bodyList:
        bod.x = headPosX[contador]
        bod.y = headPosY[contador]
        contador += 1
    if len(headPosX)>(scoreS+1):
        headPosX.pop()
    if len(headPosY)>(scoreS+1):
        headPosY.pop()  
        
def generarCuadro():
    global cuadro, hayCuadro
    cuadro.x = randrange(20,780,10)
    cuadro.y = randrange(20,380,10)
    cuadro.draw(s)
    hayCuadro = True

def crecer():
    if scoreS%2:
        body = makePicture("Images\\pixelR.png")
    else:
        body = makePicture("Images\\pixel.png")
    body.border = 0
    body.x = headPosX[-1]
    body.y = headPosY[-1]
    body.draw(s)
    bodyList.append(body)
    
def comerCuadro():
    global scoreS, hayCuadro
    if cuadro.x == head.x and cuadro.y == head.y:
        cuadro.undraw()
        scoreS += 1
        hayCuadro = False
        crecer()
        
def esChoqueS():
    #Ancho y alto serpiente: 10px
    #Borde: (10,10),(790,390)
    posX = headPosX[1:]
    posY = headPosY[1:]
    if (head.x>=780 or head.x<=20 or head.y<=20 or head.y>=380):
        return True
    for i in range(1, len(bodyList)):
        bod = bodyList[i]
        if bod.x == head.x and bod.y == head.y:
            return True
    return False
    
def reiniciar():
    global startS
    startS = False
    newGameS.draw(s)
    end.draw(s)
    newGameS.connect("click",resetS)
    end.connect("click",endGame)
    
def resetS(btn,e):
    global scoreS, bodyList, headPosX, headPosY, hayCuadro
    scoreS = 0
    for bod in bodyList:
        bod.undraw()
    if snakeHigh!="":
        snakeHigh.undraw()
    bodyList = []
    headPosX = []
    headPosY = []
    high = []
    head.undraw()
    head.x = 400
    head.y = 200
    cuadro.undraw()
    newGameS.Visible = False
    hayCuadro = False
    end.Visible = False
    darInicio()

def mostrarPuntajeS():
    puntaje = Text((780,25),str(scoreS))
    puntaje.xJustification = "right"
    puntaje.fontSize = 20
    puntaje.draw(s)
    puntS.insert(0,puntaje)
    puntS[-1].undraw()
    puntS.pop()

def newHighscoreS():
    global snakeHigh
    snakeHigh = Text((400,100),"New Highscore! \n" + str(scoreS))
    snakeHigh.xJustification = "center"
    snakeHigh.fontSize = 20
    snakeHigh.draw(s) 

def puntajeMaxS():
    archivo = open("Top5\\TopSnake.txt","r")
    cadena = archivo.readline()
    highscore = cadena.split(":")
    puntaje = Text((400,100),"Highscore: " + highscore[-1])
    puntaje.fontSize = 20
    puntaje.draw(s)
    high.append(puntaje)
    archivo.close()
    
def guardarScore():
    archivo = open("Top5\\TopSnake.txt","r")
    top5 = archivo.readlines()
    nTop5 = top5[:]
    archivo.close()
    contador = 0
    top = False
    for guardados in nTop5:
        lista = guardados.split(":")
        if scoreS > int(lista[-1]):
            top = True
            break
        contador += 1
    if top:
        playerN = str(input(str(contador + 1) + " PLACE-- PLAYER NAME"))
        nTop = playerN + ": " + str(scoreS) + "\n"
        nTop5.insert(contador,nTop)
        if contador == 0:
            newHighscoreS()
        if len(nTop5) > 5:
            nTop5.pop()
    arc = open("Top5\\TopSnake.txt","w")
    for nScores in nTop5:
        print(nScores)
        arc.write(nScores)
    print()
    arc.close()  
                          
def resetTopS(btn,e):
    archivo = open("Top5\\TopSnake.txt","w")
    archivo.write("CPU: 0\n")
    archivo.close()
    high[-1].undraw()
    high.pop()
    puntajeMaxS()            
    
def endGame(btn,e):
    global juegoS
    juegoS = False        
                                                            
def mainS():
    darInicio()
    onKeyPress(moverSnake)
    while juegoS:
        if startS:
            animarSnake()
            mostrarPuntajeS()
            if hayCuadro == False:
                generarCuadro()
            comerCuadro()
            if esChoqueS():
                reiniciar()
                guardarScore()
        s.step(0.05)
        
s.run(mainS)