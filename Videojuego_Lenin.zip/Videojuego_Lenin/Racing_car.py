#encoding:UTF-8
#Lenin Silva Gtz, A01373214
#Racing Cars

from Graphics import *
from random import randint
from Myro import makeSound, play

#Ventana
v = Window("RACING CAR",400,750)
#Orillas
borderL = Rectangle((0,0),(40,850))
borderR = Rectangle((360,0),(400,750))
borderL.color = Color("black")
borderR.color = Color("black")
borderL.draw(v)
borderR.draw(v)

#Carro del usuario y juego
btn_r = Button((100,500),"  RED  ")
btn_b = Button((150,500), "  BLUE ")
btn_g = Button((200,500), "GREEN")
btn_n = Button((250,500), "BLACK")
carro = ""
autos = []
color = "purple"
sonido = makeSound("SoundEffects\\Racing2.wav")
soundEffect = False
soundStart = 1
sound = Button((200,600),"SOUND EFFECTS")
soundImg = makePicture("Images\\Sound.png")
soundL = [soundImg]

#Velocidad de los autos
vel = 5
vel_jugador = 25

#Variables y elementos de puntaje y nivel
score = 0
temp_score = 0
punt_list = []
level_list = []
highscore = ""
resH = Button((100,600), "RESET TOP5")

#Elementos de inicio, nuevo juego y controles
inicio = 0
newGame = Button((150, 375), "NEW GAME")
controles = makePicture("Images\\controles.png")
controles.x = 200
controles.y = 300
controles.border = 0

btn_list = [btn_r,btn_b,btn_g,btn_n,sound,resH]
 
def asignarColor(btn, e): #El usuario elige el color del auto. Esta función se ejecuta a través de un botón
    global carro, inicio, autos, color, soundStart
    ###############################################
    #Borra los autos de los juegos anteriores de manera definitiva
    if carro!="":
        carro.undraw()
    for auto in autos:
        auto.undraw()
    autos = []
    ###############################################
    if btn == btn_r:
        carro = makePicture("Images\\car_r.png")
        color = "red"
    elif btn == btn_b:
        carro = makePicture("Images\\car_b.png")
        color = "blue"
    elif btn == btn_g:
        carro = makePicture("Images\\car_g.png")
        color = "green"
    else:
        carro = makePicture("Images\\car.png")
        color = "purple"
    #########################################
    #Borra de la pantalla lo elementos de inicio
    for i in btn_list:
        i.Visible = False
    controles.undraw()
    soundImg.undraw()
    #########################################
    
    #Características del auto del usuario  
    carro.border = 0      
    carro.x = 300
    carro.y = 650
    carro.draw(v)
    if soundEffect and soundStart==1:
        play("SoundEffects\\StartCar.wav")
        v.step(2.5)
        soundStart += 1    
    crearAutos(randint(0,2))#Crea el primer auto del juego
    inicio = 1 #Puede iniciar el juego

def elementosInicio(): #El usuario selecciona un botón para elegir auto
    ##################################
    #Botones para elegir carro
    for btn in btn_list:
        btn.draw(v)
    #################################
    controles.draw(v) #Instrucciones
        
    btn_r.connect("click", asignarColor)
    btn_b.connect("clicl",asignarColor)
    btn_g.connect("click", asignarColor)
    btn_n.connect("click", asignarColor)
    resH.connect("click", resetTop5)#Se reinicia el top 5
    sound.connect("click", activarDesactivarSonido)
    
def moverCarro(v,e): #Con esta opción el auto se puede mover. Se establecen límites en 'x' y 'y'
    tecla = e.key
    if soundEffect:
        sonido.Play(1,1175)
    #El auto s puede mover en: x = (100,300); y = (150,650)
    if tecla == "Right":
        if carro.x<300:
            carro.x += 100
    elif tecla =="Left":
        if carro.x>100:
            carro.x -= 100
    elif tecla == "Up":
        if carro.y>150:
            carro.y -= vel_jugador            
    elif tecla == "Down":
        if carro.y<650:
            carro.y += vel_jugador  
                   
def crearAutos(posicion):#Crea autos en tres posiciones diferentes. Es aleatoria la selección
    #Formato del auto del juego
    nuevoAuto = makePicture("Images\\car.png")
    nuevoAuto.border = 0
    nuevoAuto.y = -20
    if posicion == 0:#Carril izquierdo
        nuevoAuto.x = 80
    elif posicion == 1:#Carril central
        nuevoAuto.x = 200
    else: #Carril derecho
        nuevoAuto.x = 320
    autos.append(nuevoAuto) #Agrega el nuevo auto a la lista de autos
    nuevoAuto.draw(v)#Lo dibuja en la pantalla

def animarAutos():
    for auto in autos: #Anima todos los autos en la lista
        auto.y += vel
        if auto>800: #Borra los autos de la pantalla y de la lista si sobrepasan el límite en 'y'
            autos.remove(auto)
            auto.undraw(v)                              
            
def mostrarPuntaje(): #Muestra el puntaje actual del jugador
    global score, temp_score
    if temp_score > 10:#regula la velocidad con la que aumenta en el score
        score += 1
        temp_score = 0  
    temp_score += 1
    puntaje = Text((350,50),str(score)) #Crea el texto que muestra el score
    #formato del texto
    puntaje.color = Color(color)
    puntaje.fontSize = 40
    puntaje.xJustification = "right"
    puntaje.draw(v) #Muestra el puntaje en la pantalla
    punt_list[-1].undraw()#Elimina de la pantalla el último puntaje en la lista (step anterior)
    punt_list.pop()#Elimina de la lista el último elemento guardado
    #Añade a la lista el texto del puntaje actual, para que en el siguiente step se borre y elimine 
    punt_list.append(puntaje)
    
def puntajeMax(): #Muestra el puntaje máximo al inicio del juego
    #Recurre al archivo de puntajes guardados
    archivo = open("Top5\\TopCar.txt","r")
    cadena = archivo.readline()#Lee solamente el primer puntaje (Highscore)
    highscore = cadena.split(":") #Crea una lista
    #Recupera el último elemento de la lista (puntaje)
    puntaje = Text((200,50), "Highscore: " +highscore[-1]) #Crea el texto
    #Le da formato al texto
    puntaje.color = Color(color)
    puntaje.fontSize = 40
    puntaje.draw(v)
    #Añade a a la lista de puntaje y nivel el texto de highscore
    #Esto es sólo para que tengan un elemento que pueda ser eliminado
    #De lo contrario, marcará error al querer obtener el elemento [-1] de una lista vacía
    punt_list.append(puntaje)
    level_list.append(puntaje)
    archivo.close() #Cierra el archivo
          
def subirNivel(): #Muestra el nivel en el que está el jugador
    global vel, vel_jugador
    #El nivel depende del score
    #Conforme avanza de nivel, la velocidad de los autos y del carro del usuario cambia
    if score<50:
        level = "0"
    elif score<125:
        level = "1"
        vel = 7
    elif score <250:
        level = "2"
        vel = 12
        vel_jugador = 30
    elif score<350:
        level = "3"
        vel = 18
        vel_jugador = 35
    elif score < 450:
        level = "4"
        vel = 24
        vel_jugador = 40
    else:
        level = "Max"
        vel = 30
        vel_jugador = 45
        
    #Crea el texto del nivel actual
    nivel = Text((50,50), "Level: " +level)
    #Le da formato al texto
    nivel.color = Color(color)
    nivel.fontSize = 40
    nivel.xJustification = "left"
    nivel.draw(v)#Dibuja el texto del nivel actual
    level_list[-1].undraw()#Borra de la pantalla el texto del nivel del step anterior
    level_list.pop()#Borra de la lista el texto de nivel anterior
    level_list.append(nivel)#Añade a la lista el texto de nivel actual, para ser borrado en el siguiente step
    
def esChoque(): #Revisa que el auto no haya chocado. Regresa booleano
    #Ancho del auto: 72px
    #Alto del auto: 96px 
    for car in autos: #Revisa cada auto de la lista
        if ((carro.x>= (car.x-72) and carro.x<= (car.x+72))and (carro.y>= (car.y-96) and carro.y<=(car.y+96))):
            if soundEffect:
                #sonido.Stop()
                play("SoundEffects\\Crash2.wav")
            return True
    return False

def newHighscore(): #Indica que se rompió el rércord anterior y lo dibuja
    global highscore
    #Crea el texto en la pantalla y le da formato
    highscore = Text((200,200),"New Highscore! \n" + str(score))
    highscore.color = Color(color)
    highscore.xJustification = "center"
    highscore.fontSize = 40
    highscore.draw(v)

def guardarScore(): #Si el puntaje entra en el top 5, lo guarda
    archivo = open("Top5\\TopCar.txt","r")#Abre el archivo de highscore para leerlo
    top5 = archivo.readlines()#Hace la lista con los highscores
    n_top5 = top5[:]
    archivo.close()
    contador = 0
    top = False
    for guardados in n_top5: #Revisa cada elemento de la lista
        lista = guardados.split(":") #Divide la cadena en otra lista
        #Revisa el puntaje guardado, y si el score es mayor, detiene el loop
        if score > int(lista[-1]): 
            top = True
            break
        contador += 1
    if top: #si el score fue igual o mayor que alguno del top5
        #Pide al jugador su nombre y lo vincula con su score
        player_name = str(input(str(contador + 1)+" PLACE" + "-- PLAYER NAME"))#pide el nombre del jugador
        n_top = player_name + ": " + str(score)#Le da el formato común a los highscores
        n_top5.insert(contador, n_top+"\n")
        if contador == 0:#Determina si fue un nuevo récord. Si es así, dibuja el mensaje con la función newHighscore()
            newHighscore()
        if len(n_top5)>5:
            n_top5.pop() #Borra el último elmento si es que no entra en el top 5
                  
    arc = open("Top5\\TopCar.txt","w") #Abre el archivo highscore para escribir en él
    for n_scores in n_top5: #Escribe en el archivo el top 5 y lo guarda
        print(n_scores) #Muestra en el shell el top5
        arc.write(n_scores)#Escribe los nuevos puntajes altos
    arc.close()#cierra el archivo
  
def finalizarJuego():#Corre si se detecta choque para finalizar esa partida
    global inicio
    inicio = 0 #Así no corre lo que está dentro de While
    newGame.draw(v) #Dibuja el botón de nuevo juego
    newGame.connect("click", reset) #Si es seleccionado, se reinicia el juego
    
def reset(btn,e): #Esta función se activa con el botón nuevo juego. Limpia la pantalla y reinicia
    global score, carro, vel, vel_jugador, temp_score, highscore,autos,punt_list,level_list, soundStart, soundEffect
    #Limpia la pantalla
    carro.undraw()
    for car in autos:
        car.undraw()
    for punt in punt_list:
        punt.undraw()
    for level in level_list:
        level.undraw() 
    if highscore!="": #Sólo corre si apareció el mensaje de "New Hihscore"
        highscore.undraw()
    #Resetea las listas y las variables a su valor del inicio del juego        
    autos = []
    punt_list = []
    level_list = []
    vel = 5
    vel_jugador = 25
    score = 0
    temp_score = 0
    soundStart = 1
    newGame.Visible = False #borra de la pantalla el botón de "New Game"
    start() #Corre nuevamente el código de inicio

def resetTop5(btn,e): #Resetea el Top5. Se llama a través de un botón
    archivo = open("Top5\\TopCar.txt","w") #Abre el archivo "Highscore" para escribir en él
    archivo.write("CPU: 0\n")
    archivo.close()
    punt_list[-1].undraw()#Borra de la pantalla el texto con highscore
    punt_list.pop()#Elimina ese elemento
    puntajeMax()#Llama a la función para dibujar el Highscore ya reseateado    

def activarDesactivarSonido(btn,e):
    global soundEffect, soundImg
    soundEffect = not(soundEffect)  
    if soundEffect:
        soundImg = makePicture("Images\\Sound.png")
    else:
        soundImg = makePicture("Images\\NoSound.png")
    soundImg.x = 200
    soundImg.y = 170
    soundImg.border = 0
    soundImg.draw(v)
    soundL[-1].undraw()
    soundL.pop()
    soundL.append(soundImg)
            
                                    
def start(): #Código de inicio
    elementosInicio() 
    puntajeMax() 
            
def main():
   start()#Corre el código de inicio
   onKeyPress(moverCarro)#Hace que el carro se mueva según la flecha que presione el jugador
   while True:
        if inicio!=0: #En tanto inicio sea 0, no correrá
            if autos[-1].y>275:#Solo crea autos si hay una separación de 250px con el auto anterior
                crearAutos(randint(0,2))
            animarAutos()#Hace que los autos se muevan
            mostrarPuntaje()#Muestra el puntaje
            subirNivel()#Muestra el nivel
            if esChoque():#Revisa que no haya colisiones.
                #Si hay colisión, el juego acaba
                guardarScore()#Se revisa si el score entra en el top5
                finalizarJuego() #finaliza el juego. Muestra la opción de empezar de neuvo
        v.step(0.025)
        
v.run(main)