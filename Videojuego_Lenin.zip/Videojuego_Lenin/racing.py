#encoding:UTF-8
#Lenin Silva Gtz, A01373214
#Código Racing Car

from Graphics import *
from random import randint
from Myro import makeSound, play

#Ventana
rC= Window("RACING CAR",400,750)
#Escenario
borderL = Rectangle((0,0),(40,850))
borderR = Rectangle((360,0),(400,750))
borderL.color = Color("black")
borderR.color = Color("black")
borderL.draw(rC)
borderR.draw(rC)

#Carro del usuario y juego
btnR = Button((100,500),"  RED  ")
btnB = Button((150,500),"  BLUE ")
btnG = Button((200,500),"GREEN")
btnN = Button((250,500),"BLACK")
carro ="" #Carro del jugador
autos = []

#Efectos de sonido
sonido = makeSound("SoundEffects\\Racing2.wav")
soundEffect = False
soundStart = 1
soundRC = Button((200,600),"SOUND EFFECTS")
soundImg = makePicture("Images\\Sound.png")
soundL = [soundImg]

#Velocidad de los autos
vel = 5
velJugador = 25

#Variables y elementos de puntaje y nivel
scoreRC = 0
tempScore = 0
puntList = []
levelList = []
color = "purple"
carHigh = ""
resHRC = Button((100,600),"RESET TOP 5")

#Elementos de inicio, nuevo juego y controles
startRC = False
newGameRC = Button((150,375),"NEW GAME")
controlesRC = makePicture("Images\\controles.png")
controlesRC.x = 200
controlesRC.y = 300
controlesRC.border = 0
endRC = Button((150, 425),"END GAME")

juegoRC = True

btnList = [btnR,btnB,btnG,btnN,soundRC,resHRC]

def elementosInicioRC():#Muestra los botones para elegir auto, resetear score, y activar sonido
    for btn in btnList:
        btn.draw(rC)
    controlesRC.draw(rC)
    
    btnR.connect("click",asignarColor)
    btnB.connect("click",asignarColor)
    btnG.connect("click",asignarColor)
    btnN.connect("click",asignarColor)
    resHRC.connect("click",resetTop5)
    soundRC.connect("click",activarDesactivarSonido)
    
def asignarColor(btn, e):#Asigna el color del auto según el botón seleccionado. Comienza el juego
    global carro, startRC, autos, color, soundStart
    #//////////////////////////////////////
    #Borra los autos de los juegos anteriores de manera definitiva
    if carro!="":
        carro.undraw()
    for auto in autos:
        auto.undraw()
    auto = []
    #//////////////////////////////////////
    if btn == btnR:
        carro = makePicture("Images\\car_r.png")
        color = "red"
    elif btn == btnB:
        carro = makePicture("Images\\car_b.png")
        color = "blue"
    elif btn == btnG:
        carro = makePicture("Images\\car_g.png")
        color = "green"
    else:
        carro = makePicture ("Images\\car.png")
        color = "purple"
    
    #Borra los elementos de inicio de la pantalla
    for btn in btnList:
        btn.Visible = False
    controlesRC.undraw()
    soundImg.undraw()
    #Características del carro del jugador
    carro.border = 0
    carro.x = 300
    carro.y = 650
    carro.draw(rC)
    if soundEffect and soundStart == 1:
        play("SoundEffects\\StartCar.wav")
        rC.step(2.5)
        soundStart += 1
    crearAutos(randint(0,2))#Crea el primer auto del juego
    startRC = True #Puede iniciar el juego
    
def moverCarro(v,e): #El auto se puede mover cuando se selecciona una tecla. Se establecen límites en 'x' y 'y'    
    tecla = e.key
    if soundEffect:
        sonido.Play(1,1175)
    #El auto se puede mover en: x = (100,300); y = (150,650)
    if tecla == "Right":
        if carro.x<300:
            carro.x += 100
    elif tecla == "Left":
        if carro.x>100:
            carro.x -= 100
    elif tecla == "Up":
        if carro.y>150:
            carro.y -= velJugador
    elif tecla == "Down":
        if carro.y<650:
            carro.y += velJugador
    
def crearAutos(posicion): #Crea autos en tres posiciones diferentes. Es aleatoria la selección
    #Formato del auto del juego
    nuevoAuto = makePicture("Images\\car.png")
    nuevoAuto.border = 0
    nuevoAuto.y = -20
    if posicion ==  0: #Carril izquierdo
        nuevoAuto.x = 80
    elif posicion == 1: #Carril central
        nuevoAuto.x = 200
    else: #Carril derecho
        nuevoAuto.x = 320
    autos.append(nuevoAuto)#Agrega el nuevo auto a la lista de autos
    nuevoAuto.draw(rC)#Lo dibuja en la pantalla

def animarAutos():
    for auto in autos: #Anima a todos los autos de la lista
        auto.y += vel
        if auto>800: #Borra los autos de la pantalla y de la lista si sobrepasan el límite en 'y'
            auto.undraw() 
            autos.remove(auto)
    
def subirNivel(): #Muestra el nivel en el que está el jugador
    #El nivel depende del score
    #Conforme avanza de nivel, la velocidad de los autos y del carro del jugador cambia
    global vel, velJugador
    if scoreRC<50:
        level = "0"
    elif scoreRC<125:
        level = "1"
        vel = 7
    elif scoreRC<250:
        level = "2"
        vel = 12
        vlJugador = 30
    elif scoreRC<350:
        level = "3"
        vel = 18
        velJugador = 35
    elif scoreRC<450:
        level = "4"
        vel = 24
        velJugador = 40
    else:
        level = "Max"
        vel = 30
        velJugador = 45
         
    #Crea el texto del nivel actual
    nivel = Text((50,50), "Level: " + level)
    #Le da formato al texto
    nivel.color = Color(color)
    nivel.fontSize = 40
    nivel.xJustification = "left"
    nivel.draw(rC) #Dibuja el texto del nivel actual
    levelList[-1].undraw() #Borra de la pantalla el texto del nivel del step anterior
    levelList.pop() #Borra de la lista el texto de nivel anterior
    levelList.append(nivel) #Añade a la lista el texto de nivel actual, para ser borrado en el siguiente step
    
def esChoqueRC(): #Revisa que el auto no haya chocado. Regresa booleano
    #Ancho del auto: 72px
    #Alto del auto: 96px
    for car in autos: #Revisa cada auto de la lista
        if ((carro.x >= (car.x-72) and carro.x <= (car.x+72))and (carro.y >= (car.y-96)and carro.y <= (car.y+96))):
            if soundEffect:
                play("SoundEffects\\Crash2.wav")
            return True
    return False
        
def finalizarJuegoRC():#corre si detecta choque para finalizar esa partida
    global startRC
    startRC = False #Así no corre lo que está dentro del while
    newGameRC.draw(rC) #Dibuja el botón de nuevo juego
    endRC.draw(rC)
    newGameRC.connect("click", resetRC)#Si es seleccionado, se reinicia el juego
    endRC.connect("click", endGameRC)
    
def resetRC(btn,e):#Esta función se activa con el botón New Game. Limpia la pantalla y reinicia
    global scoreRC, carro, vel, velJugador, tempScore, carHigh, autos, puntList, levelList, soundStart, soundEffect, newGameRC
    #Limpia la pantalla
    carro.undraw()
    for car in autos:
        car.undraw()
    for punt in puntList:
        punt.undraw()
    for level in levelList:
        level.undraw()
    if carHigh != "":#Sólo corre si apareció el mensaje de "New Highscore"
        carHigh.undraw()
    #Resetea las listas y las variables a su valor del inicio del juego
    autos = []
    puntList = []
    levelList = []
    vel = 5
    velJugador = 25
    scoreRC = 0
    tempScore = 0
    soundStart = 1
    newGameRC.Visible = False #borra de la pantalla el botón de "New Game"
    endRC.Visible = False
    iniciarRC() #Corre nuevamente el código de inicio
    
def activarDesactivarSonido(btn,e):
    global soundEffect, soundImg
    soundEffect = not(soundEffect)
    if soundEffect:
        soundImg = makePicture("Images\\Sound.png")
    else:
        soundImg = makePicture("Images\\NoSound.png")
    soundImg.x = 200
    soundImg.y = 170
    soundImg.border = 0
    soundImg.draw(rC)
    soundL[-1].undraw()
    soundL.pop()
    soundL.append(soundImg)
    
def iniciarRC(): #código de inicio
    elementosInicioRC()
    puntajeMaxRC()
    
def mostrarPuntajeRC():#Muestra el puntaje actual del jugador
    global scoreRC, tempScore
    if tempScore > 10: #REgula la velocidad con la que aumenta el score
        scoreRC += 1
        tempScore = 0
    tempScore += 1
    puntaje = Text((350,50),str(scoreRC))#Crea el texto que muestra el score
    #formato del texto
    puntaje.color = Color(color)#El color del texto es el mismo que el del coche
    puntaje.fontSize = 40
    puntaje.xJustification = "right"
    puntaje.draw(rC)#Muestra el puntaje en la pantalla
    puntList[-1].undraw() #Borra de la pantalla el último puntaje de la lista (step anterior)
    puntList.pop()#Elimina de la lista el último elemento guardado
    #Añade a la lista el texto del puntaje actual, para que en el siguiente step se borre y elimine
    puntList.append(puntaje)

def puntajeMaxRC(): #Muestra el puntaje máximo al inicio del juego
    #Recurre al archivo de puntajes guardados
    archivo = open("Top5\\TopCar.txt", "r")
    cadena = archivo.readline()#Lee solamente el primer puntaje (Highscore)
    highscore = cadena.split(":")#Crea una lista
    #Recupera el último elemento de la lista (puntaje)
    puntaje = Text((200,50), "Highscore: " + highscore[-1])#Crea el texto
    #Formato del texto
    puntaje.color = Color(color)#Tiene el mismo color del auto del jugador
    puntaje.fontSize = 40
    puntaje.draw(rC)
    #Añade a la lista de puntaje y nivel el texto de highscore
    #Esto es sólo para que tengan un elemento que pueda ser eliminado
    #De lo contrario, marcará error al querer obtener el elemento [-1] de una lista vacía
    puntList.append(puntaje)
    levelList.append(puntaje)
    archivo.close()#Cierra el archivo

def newHighscoreRC(): #Indica que se rompió el récord anterior y lo dibuja
    global carHigh
    #Crea el texto en la pantalla y le da formato
    carHigh = Text((200,200), "New Highscore! \n" + str(scoreRC))
    carHigh.color = Color(color)#Tiene el mismo color que el auto del usuario
    carHigh.xJustification = "center"
    carHigh.fontSize = 40
    carHigh.draw(rC)
    
def guardarScore(archivoH, newHigh,score):#Si el puntaje entra en el top5, lo guarda
    #Nota: no funcionó usar '+' para leer y escribir en un archivo
    #Formato del los scores guardados: 'nombre: score \n'
    archivo = open(archivoH,"r")#Abre el archivo de TopCar para leerlo   
    top5 = archivo.readlines()#Hace la lista con el top5
    nTop5 = top5[:]#Crea una lista idéntica
    archivo.close() #Cierra el archivo
    contador = 0 #sirve para saber el lugar que ocupará el score
    top = False
    for guardados in nTop5: #Revisa cada elemento de la lista
        lista = guardados.split(":")#Divide la cadena en otra lista
        #Revisa el puntaje guardad, y si el score es mayor, detiene el loop
        if score > int(lista[-1]):
            top = True
            break
        contador += 1
    if top: #Si el score fue igual o mayor que alguno del top5
        #Pide al jugador su nombre y lo vincula con su score
        playerN = str(input(str(contador + 1) + " PLACE -- PLAYER NAME"))#Pide el nombre del jugador
        nTop = playerN + ": " + str(score) + "\n" #Le da el formato común a los highscores
        nTop5.insert(contador, nTop)
        if contador == 0:#Determina si fue un nuevo récord
            #Dibuja el mensaje con la función newHighscoreRC()
            newHigh
        if len(nTop5) > 5:
            nTop5.pop()#Borra el último elementos si es que no entra en el top5
    arc = open(archivoH,"w")#Abre el archivo TopCar para escribir en él
    for nScores in nTop5:#Escribe en el archivo el top5 y lo guarda
        print(nScores)#Muestra en el shell el top5
        arc.write(nScores)#Escribe los nuevos puntajes altos
    print()
    arc.close()#cierra el archivo
        
def resetTop5(btn,e): #Resetea el top5. Se llama con un botón
    archivo = open("Top5\\TopCar.txt","w")#Abre el archivo TopCar para escribir en él
    archivo.write("CPU: 0\n")
    archivo.close()
    puntList[-1].undraw()#Borra de la pantalla el texto con highscore
    puntList.pop() #Elimina ese elemento
    puntajeMaxRC()#Llama a la función para dibujar el highscore ya reseteado
    
def endGameRC(btn,e):
    global juegoRC
    juegoRC = False
                           
def mainRC():
    iniciarRC()#Corre el código de inicio
    onKeyPress(moverCarro)#Hace que el carro se mueve según la flecha que presione el jugador
    while juegoRC:
        if startRC: #En tanto inicio sea False, no correra
            if autos[-1].y > 275: #Sólo crea autos si hay una separación de 250px con el auto anterior
                crearAutos(randint(0,2))
            animarAutos()#Hace que los autos se muevan
            mostrarPuntajeRC()#Muestra el puntaje
            subirNivel()#Muestra el nivel
            if esChoqueRC():#Revisa si hay colisiones
                #Si hay colisión, el juego acaba
                guardarScore("Top5\\TopCar.txt", newHighscoreRC(),scoreRC)# Se revisa si el score entra en el top5
                finalizarJuegoRC()#Finaliza el juego. Muestra la opción de empezar de nuevo
        rC.step(0.025)
rC.run(mainRC)