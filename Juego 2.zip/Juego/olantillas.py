#encoding: UTF-8
from random import*
from Myro import*
v=Window("juego",800,600)
letras = ["a","b","c","d","e","f","g","h","i","j","k","l","m","o","p","q","r","s","t","u","v","w","x","y","z"]
shuffle(letras)
letras = letras[0:6]
print(letras)
Usuario=[]
def leerTecla(ventana,evento) :
    tecla = evento.key
    Usuario.append(tecla)
    if letras==Usuario:
        print (True)
    else:
        print (False)
onKeyPress(leerTecla)