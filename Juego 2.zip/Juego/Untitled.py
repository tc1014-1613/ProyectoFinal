#encoding: UTF-8
#Autor: Hector David Hernandez Rodriguez
#Estructura de un videojuego basico
from Graphics import *
from Myro import*
from random import*
v = Window ("Juego",700,400)
def Tablero():
    fondo=makePicture("fondo juego.png")
    fondo.draw(v)
    correr=makePicture("1.gif")
    correr1=makePicture("2.gif")
    correr2=makePicture("3.gif")
    correr3=makePicture("4.gif")
    correr4=makePicture("5.gif")
    while True:
        correr.draw(v)
        v.step(.3)
        correr.undraw()
        correr1.draw(v)
        v.step(.3)
        correr1.undraw()
        correr2.draw(v)
        v.step(.3)
        correr2.undraw()
        correr3.draw(v)
        v.step(.3)
        correr3.undraw()
        correr4.draw(v)
        v.step(.3)
        correr4.undraw()
letras = ["a","b","c","d","e","f","g","h","i","j","k","l","m","o","p","q","r","s","t","u","v","w","x","y","z"]
shuffle(letras)
letras = letras[0:1]
print(letras)
Usuario=[]
def leerTecla(ventana,evento) :
    tecla = evento.key
    Usuario.append(tecla)
    print(Usuario)
    if letras==Usuario:
        print (True)
    else:
        print (False)
print (letras)
Letrero=Text((400,300),letras)
onKeyPress(leerTecla)
Tablero()
