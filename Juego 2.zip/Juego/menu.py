#encoding: UTF-8
#Hector David Hernandez Rodriguez

from Myro import*
from Graphics import*
from random import*
import Myro
v=Window("Juego",600,400)
def Tablero():
    fondo=makePicture("fondo juego.png")
    fondo.draw(v)
    correr=makePicture("1.gif")
    correr1=makePicture("2.gif")
    correr2=makePicture("3.gif")
    correr3=makePicture("4.gif")
    correr4=makePicture("5.gif")
    while True:
        correr.draw(v)
        v.step(.2)
        correr.undraw()
        correr1.draw(v)
        v.step(.2)
        correr1.undraw()
        correr2.draw(v)
        v.step(.2)
        correr2.undraw()
        correr3.draw(v)
        v.step(.2)
        correr3.undraw()
        correr4.draw(v)
        v.step(.2)
        correr4.undraw()
def menu():
    
    mega=makePicture("frame-01.gif")
    mega1=makePicture("frame-02.gif")
    mega2=makePicture("frame-03.gif")
    mega3=makePicture("frame-04.gif")
    mega4=makePicture("frame-05.gif")
    mega5=makePicture("frame-06.gif")
    mega6=makePicture("frame-07.gif")
    mega7=makePicture("frame-08.gif")
    mega8=makePicture("frame-09.gif")
    mega9=makePicture("frame-10.gif")
    mega10=makePicture("frame-11.gif")
    mega11=makePicture("frame-12.gif")
    mega12=makePicture("frame-13.gif")
    Myro.play("Music.wav")
    v.step(.02)
    mega.draw(v)
    v.step(.02)
    mega1.draw(v)
    v.step(.02)
    mega2.draw(v)
    v.step(.02)
    mega3.draw(v)
    v.step(.02)
    mega4.draw(v)
    v.step(.02)
    mega5.draw(v)
    v.step(.02)
    mega6.draw(v)
    v.step(.02)
    mega7.draw(v)
    v.step(.02)
    mega8.draw(v)
    v.step(.02)
    mega9.draw(v)
    v.step(.02)
    mega10.draw(v)
    v.step(.02)
    mega11.draw(v)
    v.step(.02)
    mega12.draw(v)
    v.step(.02)
    titulo = Text((50,50),"Megaman")
    titulo.fontSlant
    titulo.draw(v)
    v.close
    open("Instrucciones.txt","r")
    Tablero()
menu()
while True:
    Tablero()
    letras = ["a","b","c","d","e","f","g","h","i","j","k","l","m","o","p","q","r","s","t","u","v","w","x","y","z"]
    shuffle(letras)
    letras = letras[0:1]
    print(letras)
    Usuario=[]
    def leerTecla(ventana,evento) :
        tecla = evento.key
        Usuario.append(tecla)
        if letras==Usuario:
            print (True)
            onKeyPress(leerTecla)
        else:
            print (False)

onKeyPress(leerTecla)
