#Morales Rodriguez Oswaldo
#A01378566
#Encoding: UTF-8
#Videojuego

from Graphics import*
from random import randint
from Myro import*



#Globales
v = Window("Autodromo Rodriguez",1500,900) #Ventana de juego
incAutosFrente = 10         #-Izquierda
incMonedas = incAutosFrente/2               #-Izquierda
AutoJugador = makePicture("Imagenes/Auto jugador 2.png") #Iniciar Auto jugador
AutoRival1 = makePicture("Imagenes/Auto rival.png")
AutoRival2 = makePicture("Imagenes/Auto rival.png")
AutoRival3 = makePicture("Imagenes/Auto rival.png")
AutoRival4 = makePicture("Imagenes/Auto rival.png")
NuevoRival1 = makePicture("Imagenes/Auto rival.png")
NuevoRival2 = makePicture("Imagenes/Auto rival.png")
NuevoRival3 = makePicture("Imagenes/Auto rival.png")
NuevoRival4 = makePicture("Imagenes/Auto rival.png")
vida1= makePicture("Imagenes/vidas.png")
vida2= makePicture("Imagenes/vidas.png")
vida3= makePicture("Imagenes/vidas.png")
moneda1 = makePicture("Imagenes/puntos.png")
moneda2 = makePicture("Imagenes/puntos.png")
moneda3 = makePicture("Imagenes/puntos.png")
moneda4 = makePicture("Imagenes/puntos.png")
nuevaMoneda1 = makePicture("Imagenes/puntos.png")
nuevaMoneda2 = makePicture("Imagenes/puntos.png")
nuevaMoneda3 = makePicture("Imagenes/puntos.png")
nuevaMoneda4 = makePicture("Imagenes/puntos.png")
#Lista GLOBAL para guardar los autos rivales
maximo = 0
segundo = 0
tercero = 0
listaAutos = []
listaMonedas = []
condicion = False
puntos = 0
hayMOneda = False
hayCarro = False
vidas = 3
puntuaciones = []
contador = 0
btnInicio = Button((360,150),"Comenzar Juego")
btnInicio.draw(v)
btnInicio.Visible= True




def carrilRival():
    global hayCarro
    if not hayCarro:
        if (AutoRival1.x>0 and AutoRival1.x<1500) or (AutoRival2.x>0 and AutoRival2.x<1500) or (AutoRival3.x>0 and AutoRival3.x<1500) or (AutoRival4.x>0 and AutoRival4.x<1500):
            pass
        else:
            carril = randint(1,4)
            print(carril, "Carril Rival")
            return (carril)
        
def carrilMoneda():
    global hayMoneda
    if not hayMOneda:
        #hoyMoneda = True
        if (moneda1.x>0 and moneda1.x<1500) or (moneda2.x>0 and moneda2.x<1500) or (moneda3.x>0 and moneda3.x<1500) or (moneda4.x>0 and moneda4.x<1500):
            pass
        else:
            carrilM = randint(1,4)
            print(carrilM, "Carril moneda")
            return (carrilM)
    
   
    
def nuevoRival(carril):
    global hayCarro
    
    if hayCarro:
        return
    hayCarro = True
    
    if carril == 1:
        NuevoRival1 = makePicture("Imagenes/Auto rival.png")
        NuevoRival1.x = AutoRival1.x
        NuevoRival1.y = AutoRival1.y
        NuevoRival1.border = 0
        NuevoRival1.draw(v) 
        listaAutos.append(NuevoRival1) 
    elif carril == 2:
        NuevoRival2 = makePicture("Imagenes/Auto rival.png")
        NuevoRival2.x = AutoRival2.x
        NuevoRival2.y = AutoRival2.y
        NuevoRival2.border = 0
        NuevoRival2.draw(v) 
        listaAutos.append(NuevoRival2) 

    elif carril == 3:
        NuevoRival3 = makePicture("Imagenes/Auto rival.png")
        NuevoRival3.x = AutoRival3.x
        NuevoRival3.y = AutoRival3.y
        NuevoRival3.border = 0
        NuevoRival3.draw(v) 
        listaAutos.append(NuevoRival3) 
        
    elif carril == 4:
        NuevoRival4 = makePicture("Imagenes/Auto rival.png")
        NuevoRival4.x = AutoRival4.x
        NuevoRival4.y = AutoRival4.y
        NuevoRival4.border = 0
        NuevoRival4.draw(v) 
        listaAutos.append(NuevoRival4) 
        
def nuevaMoneda(carrilM):
    
    global hayMOneda
    
    if hayMOneda :
        return
    hayMOneda = True
    
    if carrilM == 1:
        nuevaMoneda1 = makePicture("Imagenes/puntos.png")
        nuevaMoneda1.x = moneda1.x
        nuevaMoneda1.y = moneda1.y
        nuevaMoneda1.border = 0
        nuevaMoneda1.draw(v) 
        listaMonedas.append(nuevaMoneda1) 
    elif carrilM == 2:
        nuevaMoneda2 = makePicture("Imagenes/puntos.png")
        nuevaMoneda2.x = moneda2.x
        nuevaMoneda2.y = moneda2.y
        nuevaMoneda2.border = 0
        nuevaMoneda2.draw(v) 
        listaMonedas.append(nuevaMoneda2) 

    elif carrilM == 3:
        nuevaMoneda3 = makePicture("Imagenes/puntos.png")
        nuevaMoneda3.x = moneda3.x
        nuevaMoneda3.y = moneda3.y
        nuevaMoneda3.border = 0
        nuevaMoneda3.draw(v) 
        listaMonedas.append(nuevaMoneda3) 
        
    elif carrilM == 4:
        nuevaMoneda4 = makePicture("Imagenes/puntos.png")
        nuevaMoneda4.x = moneda4.x
        nuevaMoneda4.y = moneda4.y
        nuevaMoneda4.border = 0
        nuevaMoneda4.draw(v) 
        listaMonedas.append(nuevaMoneda4) 
    
def leerTecla(ventana, evento):       #Funciones del auto del jugador
    tecla = evento.key
    if tecla == "Right":
        AutoJugador.x += incAutosFrente
            
    elif tecla == "Left":
        AutoJugador.x -= incAutosFrente
        
    elif tecla == "Up":
        AutoJugador.y-=220
        
    elif tecla == "Down":
        AutoJugador.y+=220
        
        
#Mueve todas los autos de global
def animarAutos(carril):
    global hayCarro
    global vidas
    
    if carril == 1:
        for AutoRival1 in listaAutos:
            AutoRival1. x -= incAutosFrente
            
            
            if AutoRival1.x < 0:
                #Borrar auto
                listaAutos.remove(AutoRival1)
                AutoRival1.undraw()
                
                hayCarro = False
                carril = carrilRival()
                nuevoRival(carril)
                
                
            elif AutoRival1.x==AutoJugador.x and AutoRival1.y == AutoJugador.y:
                beep(0.2,1045)
                vidas-=1
                
    elif carril == 2:
        for AutoRival2 in listaAutos:
            AutoRival2. x -= incAutosFrente
            
            if AutoRival2.x < 0:
                #Borrar auto
                listaAutos.remove(AutoRival2)
                AutoRival2.undraw()
                  
                hayCarro = False
                carril = carrilRival()
                nuevoRival(carril)
            elif AutoRival2.x==AutoJugador.x and AutoRival2.y == AutoJugador.y:
                beep(0.2,1045)
                vidas-=1
        
    elif carril == 3:
        for AutoRival3 in listaAutos:
            AutoRival3. x -= incAutosFrente
           
            if AutoRival3.x < 0:
                #Borrar auto
                listaAutos.remove(AutoRival3)
                AutoRival3.undraw() 
                
                hayCarro = False
                carril = carrilRival()
                nuevoRival(carril)
            elif AutoRival3.x==AutoJugador.x and AutoRival3.y == AutoJugador.y:
                beep(0.2,1045)
                vidas-=1
                
    elif carril == 4:
        for AutoRival4 in listaAutos:
            AutoRival4. x -= incAutosFrente
            
            if AutoRival4.x < 0:
                #Borrar auto
                listaAutos.remove(AutoRival4)    
                AutoRival4.undraw()  
                
                hayCarro = False
                carril = carrilRival()
                nuevoRival(carril)
            elif AutoRival4.x==AutoJugador.x and AutoRival4.y == AutoJugador.y:
                beep(0.2,1045)
                vidas-=1
                
                
def animarMonedas(carrilM):
   
    global hayMOneda
    global puntos
    
    if carrilM == 1:
        for moneda1 in listaMonedas:
            moneda1. x -= incMonedas
            if moneda1.x < 0:
                #Borrar Moneda
                listaMonedas.remove(moneda1)
                moneda1.undraw()
                hayMOneda = False
                carrilM = carrilMoneda()
                nuevaMoneda(carrilM)
            elif moneda1.x == AutoJugador.x and moneda1.y == AutoJugador.y:
                moneda1.undraw()
                puntos+=100
                beep(0.2,545)
                print(puntos)
                nuevoNivel()
                
                
    elif carrilM == 2:
        for moneda2 in listaMonedas:
            moneda2. x -= incMonedas
            if moneda2.x < 0:
                #Borrar Moneda
                listaMonedas.remove(moneda2)
                moneda2.undraw()
                hayMOneda = False
                carrilM = carrilMoneda()
                nuevaMoneda(carrilM)
            elif moneda2.x == AutoJugador.x  and moneda2.y == AutoJugador.y:
                moneda2.undraw()
                puntos+=100
                beep(0.2,545)
                print(puntos)
                nuevoNivel()
                
                
    elif carrilM == 3:
        for moneda3 in listaMonedas:
            moneda3. x -= incMonedas
            if moneda3.x < 0:
                #Borrar Moneda
                listaMonedas.remove(moneda3)
                moneda3.undraw()
                hayMOneda = False
                carrilM = carrilMoneda()
                nuevaMoneda(carrilM)
            elif moneda3.x == AutoJugador.x and moneda3.y == AutoJugador.y:
                moneda3.undraw()
                puntos+=100
                beep(0.2,545)
                print(puntos)
                nuevoNivel()
                
                
    elif carrilM == 4:
        for moneda4 in listaMonedas:
            moneda4. x -= incMonedas
            if moneda4.x < 0:
                #Borrar Moneda
                listaMonedas.remove(moneda4)
                moneda4.undraw()
                hayMOneda = False
                carrilM = carrilMoneda()
                nuevaMoneda(carrilM)
            elif moneda4.x == AutoJugador.x and moneda4.y == AutoJugador.y:
                
                moneda4.undraw()
                puntos+=100
                beep(0.2,545)
                print(puntos)
                nuevoNivel()
                



        
        
def nuevoNivel():
    global puntos
    global incAutosFrente
    
    niveles=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    acceso = puntos/100
    if (acceso in niveles):
        incAutosFrente+=10
        AutoJugador.x=0
    
        
    
    


    
def leaderboard():
    global puntos
    global puntuaciones
    global condicion
    global vidas
    
    if condicion == False and vidas == 0:
        txtFinal = Text((400,100),"Perdiste")
        txtFinal.fontSize = 44
        txtFinal.draw(v)
        archivo = open("Puntuaciones.txt","r")
        score = archivo.readline()
        while score != "":
            print(score)
            puntuaciones.append(score)
            score = archivo.readline()
        puntuaciones.append(str(puntos))
    
        archivo = open("Puntuaciones.txt","w")
        for dato in puntuaciones:
            archivo.write(dato)
            
        archivo.write("\n")
        print(puntuaciones)
        archivo.close()
        
        
        
        
        
        archivo.close()
        


        

def menu():
    global condicion 
    global vidas
    


def atenderBoton(boton, e):
    global condicion
    
    if boton==btnInicio:
        condicion = True 
        btnInicio.Visible = False  
        

           
     
        

    
    
    
        
def comprobarVidas():
    global vidas
    global condicion
    
    if vidas == 2:
        vida3.undraw()
    elif vidas == 1:
        vida2.undraw()
    elif vidas == 0:
        vida1.undraw()
        condicion = False
        



def main():

    global condicion
    global vidas
    global contador
    global maximo
    global segundo
    global tercero
    
    #Fondo
    fondo = makePicture("Imagenes/Carretera.jpg")#Por default esta en (0.0)
    fondo.draw(v)
    
    
    #Auto del Jugador
    AutoJugador.border = 0
    AutoJugador.x = 0
    AutoJugador.y = 120
    AutoJugador.draw(v)
    
    #Autos Rivales
    AutoRival1.border = 0
    AutoRival1.x = 1800
    AutoRival1.y = 120
    AutoRival1.draw(v)
    
    AutoRival2.border = 0
    AutoRival2.x = 1800
    AutoRival2.y = 340
    AutoRival2.draw(v)
    
    AutoRival3.border = 0
    AutoRival3.x = 1800
    AutoRival3.y = 560
    AutoRival3.draw(v)
    
    AutoRival4.border = 0
    AutoRival4.x = 1800
    AutoRival4.y = 780
    AutoRival4.draw(v)
    
    #Monedas para puntos
    moneda1.border = 0
    moneda1.x = 1800
    moneda1.y = 120
    moneda1.draw(v)
    
    moneda2.border = 0
    moneda2.x = 1800
    moneda2.y = 340
    moneda2.draw(v)
    
    moneda3.border = 0
    moneda3.x = 1800
    moneda3.y = 560
    moneda3.draw(v)
    
    moneda4.border = 0
    moneda4.x = 1800
    moneda4.y = 780
    moneda4.draw(v)
    
    #vidas del jugador
        
    vida1.border = 0
    vida1.x = 70
    vida1.y = 50
    vida1.draw(v)
    
    vida2.border = 0
    vida2.x = 140
    vida2.y = 50
    vida2.draw(v)
    
    vida3.border = 0
    vida3.x = 210
    vida3.y = 50
    vida3.draw(v)
    
    
    
    onKeyPress(leerTecla)
    
    while condicion == False and vidas == 3:
        btnInicio.connect("click",atenderBoton)
        if contador == 0:
            txtInicio = Text((750,100),"AutoDromo Rodriguez II")
            txtInicio.fontSize = 44
            txtInicio.draw(v)
            archivo = open("Puntuaciones.txt","r")
            score = archivo.readline()
            while score !="":
                if int(score)>maximo:
                    maximo = int(score)
                elif int(score)<maximo and int(score)>segundo or int(score) == maximo:
                    segundo = int(score)
                elif int(score)<segundo and int(score)>tercero or int(score) == segundo:
                    tercero= int(score)
                
                score = archivo.readline()
        

            
            txtPrimero = Text((750,200),str(maximo))
            txtPrimero.fontSize = 44
            txtPrimero.draw(v)
            
            txtSegundo = Text((750,300),str(segundo))
            txtSegundo.fontSize = 44
            txtSegundo.draw(v)
            
            txtTercero = Text((750,400),str(tercero))
            txtTercero.fontSize = 44
            txtTercero.draw(v)
        
            contador+=1
        else:
            continue
    txtInicio.undraw()
    txtPrimero.undraw()
    txtSegundo.undraw()
    txtTercero.undraw() 

        
    
    carrilM = carrilMoneda()
    carril = carrilRival()



    #Ciclo de Juego
    while condicion == True:     #Ciclo infinito
        v.step(0.0025)
        
        

        animarMonedas(carrilM)
        
            
        
        
        
        nuevaMoneda(carrilM)
        animarAutos(carril)
        nuevoRival(carril)
        
        comprobarVidas()
            
        
    leaderboard()
    menu()



        
           #Retardo para que no se mueva rapido el ciclo. 40 veces por segundo  
        
    
    

v.run(main)

        

    
