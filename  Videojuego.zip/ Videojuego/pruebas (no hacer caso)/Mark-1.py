#encoding: UTF-8
#Autor: Carlos E. Carbajal Nogués
#Videojuego básico

from Graphics import*
#Se crea la ventana del juego
v=Window("Juego",800,600)

disparo=makePicture("img/disparo.png")

nave=makePicture("img/nave1.png")#Agrega la nave

incPika= 3 #Movimiento del Pikashu
explosion=makePicture("img/explosion.png")
listaDisparo=[]#Creamos una lista para poder agregar pokebolas infinitas
listaEnemigos=[]#En esta lista estarán todos los enemigos
def main():
    
    fondo=makePicture("img/fondo.jpg") #Ponemos el fondo a la imagen
    fondo.draw(v)#Pone el fondo en la ventana
    
    #Nave
    nave.border=0 #Quita el marco de la imagen
    nave.x=368
    nave.y=568
    nave.draw(v)
    
    #Disparo
    disparo.border=0
    disparo.x=nave.x
    disparo.y=nave.y
    #pb.draw(v)
    
    #Pikachu
    pika=makePicture("img/Pikachu.png")
    pika.border=0
    pika.x=400
    pika.draw(v)
    
    #Explosion
    explosion.border=0
    explosion.x=pika.x
    
    
    onKeyPress(leerTecla)
    
    while True: #Ciclo del juego
        
        #fondo.x+=1 Mueve el fondo
        
        #animarPikachu(pika)
        animarDisparos(pika)
        generarEnemigos()
        
        v.step(.020) #Retardo - Ejecuta el ciclo más lento, ya no se mueve
        
def animarPikachu(pika):
    
    global incPika
    pika.x+=incPika
    
    if pika.x>=768 or pika.x<=32:
        incPika*=-1
    
def leerTecla(ventana,evento):
    
    tecla = evento.key
    
    if tecla=="Right":
        nave.x+=20
        disparo.x+=20
        #if mano.x>768 or pb.x>768
    
    elif tecla=="Left":
        nave.x-=20
        disparo.x-=20
    
    elif tecla=="space":
        # pb.y+=500
        nuevoDisparo= makePicture("img/disparo.png")
        nuevoDisparo.border=0
        nuevoDisparo.x=disparo.x
        nuevoDisparo.y=disparo.y
        nuevoDisparo.draw(v)
        listaDisparo.append(nuevoDisparo)
            
def generarEnemigos():
    for k in range(11):
        enemigo1=makePicture("img/enemigo01.png")
        enemigo1.x=30+k*70
        enemigo1.y=100
        enemigo1.border=0
        enemigo1.draw(v)
     
def animarDisparos(pika): #Hace que las pokebolas de la listan tengan movimiento
    
    for disparo in listaDisparo:
        disparo.y-=25
        
        if (disparo.x and disparo.y) == (pika.x and pika.y):
            listaDisparo.remove(disparo)
            disparo.undraw()
            pika.undraw()
            explosion.draw(v)
            #explosion.undraw()
        if disparo.y<0:
            listaDisparo.remove(disparo)   
            disparo.undraw()
            #explosion.undraw() 

v.run(main)
