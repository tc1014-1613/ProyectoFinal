#encoding: UTF-8
#Autor: Carlos E. Carbajal Nogués
#Descripción: Videojuego

#Librerias que se importan: graphics, Myro, random
from Graphics import *
from Myro import play
from random import randint

#Declaramos las variables globales
v=Window("Space Invaders", 800, 600) #La ventana del juego
nave=makePicture("img/nave1.png") #La nave que controla el jugador
disparo=makePicture("img/disparo.png") #La imagen del disparo que la nave genera
disparoEne=makePicture("img/disparo2.png") #La imagen del disparo enemigo
explosion=makePicture("img/explosion.png")#La imagen de la explosion
tablero=makePicture("img/tablero.png") #La imagen que hará nuestro tablero
enemigoEspecial=makePicture("img/enemigoEspecial.png")
listaDisparo=[] #Lista en la cual se agregarán las animaciones de disparo
listaDisparoEne=[] #Lista en la cual se guardan las animaciones de disparo enemigo
listaEnemigos=[] #Lista en la que se guardan todos los enemigos
listaPuntajes=[] #Lista en la que se guardaran todos los puntajes
incrementoEnemigo=1 #Cantidad de pixeles que se moverá el enemigo
incrementoEnemigox=4 #Cantidad de pixeles que se mover el enemigo  en el eje x en el eje x
tiempo=3501 #Tiempo que durara el juego
vidas=5 #Vidas que tiene el jugador al comenzar la partida
puntaje=0 #El puntaje que el jugador acumula
inicio=True #Esto nos dice que el juego comenzará en la pantalla de inicio
vivo=False #Esto es para saber si el jugador sigue vivo
pausa=False #No está en pausa al inciar el juego
instrucciones=False #No se mostraran las instrucciones al inciar el juego
creditos=False #No se mostraran los creditos al inciar el juego
puntajes=False #No se mostraran los puntajes al inciar el juego
infile = open('puntajes.txt', 'r') #El archivo que tiene todos los puntajes
txtInicio = Text((400,100),"SPACE INVADERS") #Texto de la pantalla de inicio
txtInstrucciones = Text((400,400),"INSTRUCCIONES \n  Los aliens quieren invadir la tierra \n Eres la única salvación que la humanidad tiene \n ¿Podrás salvarlos?  \n Usa las flechas para desplazarte a los lados \n <- Izquierda o -> Derecha \n La flecha hacia arriba disparará el láser \n Up Disparar") #Texto de las Instrucciones
txtCreditos = Text((400,400),"CREDITOS \n Hecho por: Carlos E. Carbajal Nogués \n A01373264 \n Imágenes sacadas de: google.com \n Sonidos sacados de: sonidosmp3gratis.com") #Texto de las Instrucciones
txtPuntajes = Text((400,400),"PUNTAJES"+"\n"+infile.read()) #Texto de los Puntajes
txtPuntaje = Text((180,570),"Puntaje: "+str(puntaje)) #Texto de la pantalla de inicio
txtVidas = Text((320,570),"Vidas: "+str(vidas)) #Texto de la pantalla de inicio
txtTiempo = Text((475,570),"Tiempo: "+str(tiempo)) #Texto de la pantalla de inicio
infile.close()

#Instrucciones para que el boton de Inicio sea visible
btnInicio = Button((600,560),"Inicio")
btnInicio.draw(v)
btnInicio.Visible= False

#Instrucciones para que el boton de Jugar sea visible
btnJugar = Button((380,250),"Jugar")
btnJugar.draw(v)
btnJugar.Visible= True

#Instrucciones para que el boton de Instrucciones sea visible
btnInstrucciones = Button((370,300),"Instrucciones")
btnInstrucciones.draw(v)
btnInstrucciones.Visible= True

#Instrucciones para que el boton de Creditos sea visible
btnCreditos = Button((380,350),"Creditos")
btnCreditos.draw(v)
btnCreditos.Visible= True

#Instrucciones para que el boton de Puntajes sea visible
btnPuntajes = Button((380,400),"Puntajes")
btnPuntajes.draw(v)
btnPuntajes.Visible= True

#Instrucciones para que el boton de Inicio sea visible
btnPausa = Button((600,560),"Pausa")
btnPausa.draw(v)
btnPausa.Visible= False

#Instrucciones para que el boton de Inicio sea visible
btnMenu = Button((600,560),"Menu")
btnMenu.draw(v)
btnMenu.Visible= False

#Funciones que utilizamos para correr el juego

#Funcion main()
def main():
    #Declaramos el fondo y lo dibujamos
    global tiempo
    fondo=makePicture("img/fondo.jpg")
    fondo.draw(v)
    onKeyPress(moverNave)
    darFormato(v)
    while True: #Ciclo infinito
         
         while inicio==True:
            iniciarJuego()
           
         while vivo==True:
             if tiempo%100==1:
                generarEnemigos()
             if tiempo%1000==1:
                generarEnemigosEspeciales()
             if tiempo%250==1:
                generarEnemigos2()
             while pausa==True:
                iniciarJuego() 
             ocultarBotones()
             animarDisparos()
             animarDisparosEne()
             moverDisparosEne()
             animarEnemigos()
             animarExplosion()
             actualizarTablero()
             tiempo-=1
             checarVida()
         checarJuego()         

         v.step(.001)#Paso al que el juego correra 

#Funcion para dar formato a todas los elementos utilizados
def darFormato(v):
    #Nave
    nave.border=0 #Quita el marco de la imagen
    nave.x=368
    nave.y=468
    
    #Disparo
    disparo.border=0
    disparo.x=nave.x
    disparo.y=nave.y-32
    
    #Disparo Enemigo
    disparoEne.border=0
    disparoEne.x=randint(0,800)
    disparoEne.y=0
    
    #Tablero
    tablero.border=0
    tablero.x=400
    tablero.y=600
    
#Funcion para ocultar botones 
def ocultarBotones():
    
    #Botones de Inicio
    btnInicio.Visible=False    
    btnJugar.Visible=False 
    btnInstrucciones.Visible=False 
    btnCreditos.Visible=False
    btnPuntajes.Visible=False 
    btnPausa.Visible=True
    
    #Texto
    txtInicio.undraw()
    
    #Imagenes
    nave.draw(v)
    tablero.draw(v)
    
#Funcion para que darle movimiento a la nave
def moverNave(ventana,evento):
    tecla=evento.key
    #Movimiento a la derecha
    if tecla=="Right":
        nave.x+=15
        disparo.x+=15
    
    #Movimiento a la izquierda
    elif tecla=="Left":
        nave.x-=15
        disparo.x-=15
    
    #Movimiento de los disparos
    elif tecla=="Up":
        nuevoDisparo= makePicture("img/disparo.png")
        play("sonido/explosion.wav")
        nuevoDisparo.border=0
        nuevoDisparo.x=disparo.x
        nuevoDisparo.y=disparo.y
        nuevoDisparo.draw(v)
        listaDisparo.append(nuevoDisparo)

#Funcion para animar los disparos
def animarDisparos():
    for disparo in listaDisparo:
        disparo.y-=25

        if disparo.y<0:
            listaDisparo.remove(disparo)   
            disparo.undraw()
            #explosion.undraw()

#Funcion para generar los disparos enemigos
def animarDisparosEne():
    if tiempo%5==1:
        nuevoDisparoEne= makePicture("img/disparo2.png")
        play("sonido/explosion.wav")
        nuevoDisparoEne.border=0
        nuevoDisparoEne.x=randint(0,800)
        nuevoDisparoEne.y=disparoEne.y
        nuevoDisparoEne.draw(v)
        listaDisparoEne.append(nuevoDisparoEne)

#Funcion para animar los disparos enemigos    
def moverDisparosEne():    
    global vidas, txtVidas
    for disparoEne in listaDisparoEne:
        disparoEne.y+=25

        if disparoEne.y>=469:
            listaDisparoEne.remove(disparoEne)   
            disparoEne.undraw()
        elif abs(disparoEne.x-nave.x)<30 and abs(disparoEne.y-nave.y)<30:
            txtVidas.undraw()
            disparoEne.undraw()
            listaDisparoEne.remove(disparoEne)
            explosion.border=0
            explosion.y=nave.y
            explosion.x=nave.x
            explosion.draw(v)
            play("sonido/explosion1.wav")
            vidas-=1
            txtVidas=Text((320,570),"Vidas: "+str(vidas))
            txtVidas.fontSize = 20
            txtVidas.fill=Color("white") 
            txtVidas.draw(v)
            
#Funcion que se utiliza para generar enemigos
def generarEnemigos():
    for k in range(11): 
        enemigo1=makePicture("img/enemigo01.png")
        enemigo1.x=30+k*70
        enemigo1.y=100
        enemigo1.border=0
        enemigo1.draw(v)
        listaEnemigos.append(enemigo1)

#Funcion que sirve para generar enemigos que no son comunes
def generarEnemigosEspeciales():
    global enemigoEspecial
    enemigoEspecial=makePicture("img/enemigoEspecial.png")
    enemigoEspecial.x=0
    enemigoEspecial.y=randint(50,450)
    enemigoEspecial.border=0
    enemigoEspecial.draw(v)

#Funcion que genera enemigos que valen más puntos
def generarEnemigos2():
    global enemigo2
    enemigo2=makePicture("img/enemigo02.png")
    enemigo2.x=800
    enemigo2.y=randint(50,450)
    enemigo2.border=0
    enemigo2.draw(v)    
#Funcion que anima a los enemigos
def animarEnemigos():
    #Se modifica la variable global
    global incrementoEnemigo,vidas, txtVidas
    #Se utiliza un for para animar todos los elementos de la lista
    for enemigo1 in listaEnemigos:
        enemigo1.y+=incrementoEnemigo
        if enemigo1.y>468:
            enemigo1.undraw()
            listaEnemigos.remove(enemigo1)
        elif abs(enemigo1.x-nave.x)<30 and abs(enemigo1.y-nave.y)<30:
            txtVidas.undraw()
            enemigo1.undraw()
            listaEnemigos.remove(enemigo1)
            explosion.border=0
            explosion.y=enemigo1.y
            explosion.x=enemigo1.x
            explosion.draw(v)
            play("sonido/explosion1.wav")
            vidas-=1
            txtVidas=Text((320,570),"Vidas: "+str(vidas))
            txtVidas.fontSize = 20
            txtVidas.fill=Color("white") 
            txtVidas.draw(v)
    enemigoEspecial.x+=incrementoEnemigox
    enemigo2.x-=incrementoEnemigox     
#Funcion que nos ayuda a animar la explosión de los enemigos
def animarExplosion():
    global puntaje, txtPuntaje 
    explosion.undraw()
    for enemigo1 in listaEnemigos: 
        for disparo in listaDisparo:
            if abs(enemigo1.x-disparo.x)<30 and abs(enemigo1.y-disparo.y)<30:
                txtPuntaje.undraw()
                enemigo1.undraw()
                listaEnemigos.remove(enemigo1)
                disparo.undraw()
                listaDisparo.remove(disparo)
                explosion.border=0
                explosion.y=enemigo1.y
                explosion.x=enemigo1.x
                explosion.draw(v)
                play("sonido/explosion1.wav")
                puntaje+=20
                txtPuntaje=Text((180,570),"Puntaje: "+str(puntaje))
                txtPuntaje.fontSize = 20
                txtPuntaje.fill=Color("white") 
                txtPuntaje.draw(v)
    if enemigo2.x==0:
        enemigo2.undraw()
    if enemigoEspecial.x==800:
        enemigoEspecial.undraw()
    for disparo in listaDisparo:
        if abs(enemigoEspecial.x-disparo.x)<10 and abs(enemigoEspecial.y-disparo.y)<10:
                txtPuntaje.undraw()
                enemigoEspecial.undraw()
                disparo.undraw()
                listaDisparo.remove(disparo)
                explosion.border=0
                explosion.y=enemigoEspecial.y
                explosion.x=enemigoEspecial.x
                explosion.draw(v)
                play("sonido/explosion1.wav")
                puntaje+=100
                txtPuntaje=Text((180,570),"Puntaje: "+str(puntaje))
                txtPuntaje.fontSize = 20
                txtPuntaje.fill=Color("white") 
                txtPuntaje.draw(v)     
        if abs(enemigo2.x-disparo.x)<20 and abs(enemigo2.y-disparo.y)<20:
                txtPuntaje.undraw()
                enemigo2.undraw()
                disparo.undraw()
                listaDisparo.remove(disparo)
                explosion.border=0
                explosion.y=enemigo2.y
                explosion.x=enemigo2.x
                explosion.draw(v)
                play("sonido/explosion1.wav")
                puntaje+=50
                txtPuntaje=Text((180,570),"Puntaje: "+str(puntaje))
                txtPuntaje.fontSize = 20
                txtPuntaje.fill=Color("white") 
                txtPuntaje.draw(v)     
                
#Funcion que utilizamos para la pantalla de inicio
def iniciarJuego():
   global infile
   for disparo in listaDisparo:
    disparo.undraw()
    listaDisparo.remove(disparo)
   for disparoEne in listaDisparoEne:
    disparoEne.undraw()
    listaDisparoEne.remove(disparoEne)
   txtVidas.undraw()
   txtPuntaje.undraw()
   txtTiempo.undraw()
   btnMenu.Visible=False 
   btnInicio.Visible=False    
   btnJugar.Visible=True 
   btnInstrucciones.Visible=True
   btnCreditos.Visible=True
   btnPuntajes.Visible=True
   btnPausa.Visible=False  
   txtInicio.fontSize = 85
   txtInicio.fill=Color("yellow") 
   txtInicio.draw(v)
   #Hace que las instrucciones aparezcan en pantalla
   btnInstrucciones.connect("click", mostrarInstrucciones)
   while instrucciones==True:
    txtInstrucciones.fontSize = 35
    txtInstrucciones.fill=Color("yellow") 
    txtInstrucciones.draw(v)
    btnInicio.Visible=True    
    btnJugar.Visible=False 
    btnInstrucciones.Visible=False 
    btnCreditos.Visible=False
    btnPuntajes.Visible=False 
    btnPausa.Visible=False 
    btnInicio.connect("click",regresarInicio)
   txtInstrucciones.undraw()
   #Hace que los creditos aparezcan en pantalla
   btnCreditos.connect("click", mostrarCreditos)
   while creditos==True:
    txtCreditos.fontSize = 35
    txtCreditos.fill=Color("yellow") 
    txtCreditos.draw(v)
    btnInicio.Visible=True    
    btnJugar.Visible=False 
    btnInstrucciones.Visible=False 
    btnCreditos.Visible=False
    btnPuntajes.Visible=False 
    btnPausa.Visible=False 
    btnInicio.connect("click",regresarInicio)
   txtCreditos.undraw()
   #Hace que los mejores puntajes aparezcan en pantalla
   btnPuntajes.connect("click", mostrarPuntajes)
   while puntaje==True:
    infile.close()
    txtPuntajes.fontSize = 25
    txtPuntajes.fill=Color("yellow") 
    txtPuntajes.draw(v)
    btnInicio.Visible=True    
    btnJugar.Visible=False 
    btnInstrucciones.Visible=False 
    btnCreditos.Visible=False
    btnPuntajes.Visible=False 
    btnInicio.connect("click",regresarInicio)
    
   txtPuntajes.undraw()
   #Funcion que corre el juego
   btnJugar.connect("click", empezarJuego)
   #Borrar enemigos que queden en pantalla
   for enemigo1 in listaEnemigos:
    enemigo1.undraw()
    listaEnemigos.remove(enemigo1)
   nave.undraw()
   tablero.undraw()
   
#Funcion que imprime las Instrucciones
def mostrarInstrucciones(o,e):
   global creditos, puntaje, instrucciones
   creditos=False
   puntaje=False
   instrucciones=True
   
#Funcion que imprime las Creditos
def mostrarCreditos(o,e):
   global creditos, puntaje, instrucciones
   creditos=True
   puntaje=False
   instrucciones=False
   

#Funcion que imprime los Puntajes
def mostrarPuntajes(o,e):
   global creditos, puntaje, instrucciones
   creditos=False
   puntaje=True
   instrucciones=False
   
#Funcion que regresa al inicio
def regresarInicio(e,o):
   global creditos, puntaje, instrucciones 
   btnInicio.Visible=False    
   btnJugar.Visible=True 
   btnInstrucciones.Visible=True
   btnCreditos.Visible=True
   btnPuntajes.Visible=True
   btnPausa.Visible=False 
   txtCreditos.undraw()
   txtInstrucciones.undraw()
   txtPuntajes.undraw()
   creditos=False
   puntaje=False
   instrucciones=False
   iniciarJuego() 

#Funcion que comienza el juego
def empezarJuego(e,o):
    global inicio, vivo, pausa
    inicio=False
    pausa=False
    vivo=True
    #generarEnemigos()
    
#Funcion que actualiza el tablero
def actualizarTablero():
   global txtTiempo
   txtTiempo.undraw()  
   txtTiempo = Text((475,570),"Tiempo: "+str(tiempo))
   txtTiempo.fontSize = 18
   txtTiempo.fill=Color("white") 
   txtTiempo.draw(v)
   btnPausa.connect("click",terminarJuego)
   
#Funcion para terminar el juego
def terminarJuego(e,o):
    global inicio,pausa
    pausa=True
    inicio=True
    iniciarJuego()
    
#Funcion para checar si terminó el juego
def checarJuego():
    global vidas, puntaje, tiempo, txtFinal, nave, tablero, txtTiempo, txtPuntaje, txtVidas, btnPausa, vivo, pausa
    if vidas==0:
        for enemigo1 in listaEnemigos:
            enemigo1.undraw()
            listaEnemigos.remove(enemigo1)
        for disparo in listaDisparo:
            disparo.undraw()
            listaDisparo.remove(disparo)    
        for disparoEne in listaDisparoEne:
            disparoEne.undraw()
            listaDisparoEne.remove(disparoEne)
        nave.undraw()
        enemigoEspecial.undraw()
        enemigo2.undraw()
        txtTiempo.undraw()
        txtVidas.undraw()
        txtPuntaje.undraw()
        tablero.undraw()
        btnPausa.Visible=False
        outfile = open('puntajes.txt', 'a') # Indicamos el valor 'w'.
        outfile.write(str(puntaje)+"\n")
        outfile.close()
        txtFinal=Text((400,200),"Has perdido \n La humanidad no se pudo salvar\n Tu puntaje: "+str(puntaje))
        txtFinal.fontSize = 45
        txtFinal.fill=Color("yellow") 
        txtFinal.draw(v)
        vidas=5
        puntaje=0
        tiempo=3501
        btnMenu.Visible= True
        btnMenu.connect("click", regresarMenu)
        
        
    elif tiempo==0 and vidas>0:
        for enemigo1 in listaEnemigos:
            enemigo1.undraw()
            listaEnemigos.remove(enemigo1)
        for disparo in listaDisparo:
            disparo.undraw()
            listaDisparo.remove(disparo)    
        for disparoEne in listaDisparoEne:
            disparoEne.undraw()
            listaDisparoEne.remove(disparoEne)
        enemigoEspecial.undraw()
        enemigo2.undraw()
        nave.undraw()
        txtTiempo.undraw()
        txtVidas.undraw()
        txtPuntaje.undraw()
        tablero.undraw()
        btnPausa.Visible=False
        outfile = open('puntajes.txt', 'a') # Indicamos el valor 'w'.
        outfile.write(str(puntaje)+"\n")
        outfile.close()
        txtFinal=Text((400,200),"Felicidades \n Has salvado a la humanidad\n Tu puntaje: "+str(puntaje))
        txtFinal.fontSize = 45
        txtFinal.fill=Color("yellow") 
        txtFinal.draw(v)
        vidas=5
        puntaje=0
        tiempo=3501
        btnMenu.Visible= True
        btnMenu.connect("click", regresarMenu)
        
 
#Funcion para saber si sguie vivo
def checarVida():
    global vivo
    if vidas==0:
        vivo=False
    elif tiempo==0:
        vivo=False
        
#Funcion para regresar al menu
def regresarMenu(e,o):
    global inicio, txtFinal, pausa
    txtFinal.undraw()
    inicio=True
    pausa=True
    iniciarJuego()
#Corremos el codigo
v.run(main)  
